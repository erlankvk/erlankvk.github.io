<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        
        <?php if(osc_get_preference('ads_sp_top', 'marketplace_theme')): ?>
            <div class="ads-block">
                <?php echo osc_get_preference('ads_sp_top', 'marketplace_theme'); ?>
            </div>
        <?php endif; ?>
        
        <main class="m_box c_main c_related c_search">
        	<div class="m_inb">
                <?php if(osc_get_preference('search_position', 'marketplace_theme') == 'left'): ?>
            		<aside class="c_side">
            			<div class="s_box s_catlist">
            				<div class="s_catlist-head"><?php echo osc_category_name(); ?></div>
            				<ul>
            					<?php marketplace_sidebar_category_search(osc_category_id()); ?>
            				</ul>
            			</div>
            
            			<?php osc_current_web_theme_path('inc.search.php'); ?>
            		</aside>
                <?php endif; ?>
                
        		<div class="c_cont">
        			<div class="c_single-box c_filter-line">
        				<ul class="c_filter-pp">
        					<li <?php if(Params::getParam('sCompany') == '' || Params::getParam('sCompany') == null): ?>class="active"<?php endif; ?>>
                                <a href="<?php echo osc_esc_html(osc_update_search_url(array('sCompany'=> ''))); ?>"><?php _e('All', 'marketplace') ?></a>
                            </li>
        					<li <?php if(Params::getParam('sCompany') === '0'): ?>class="active"<?php endif; ?>>
                                <a href="<?php echo osc_esc_html(osc_update_search_url(array('sCompany'=> 0))); ?>"><?php _e('Individual', 'marketplace') ?></a>
                            </li>
        					<li <?php if(Params::getParam('sCompany') == '1'): ?>class="active"<?php endif; ?>>
                                <a href="<?php echo osc_esc_html(osc_update_search_url(array('sCompany'=> 1))); ?>"><?php _e('Companies', 'marketplace') ?></a>
                            </li>
        				</ul>
                        
        				<div class="c_select c_filter-select">
        					<select class="selectpicker" data-size="7" onchange="location = this.value;">
                                <?php $orders = osc_list_orders(); ?>
                                <?php foreach($orders as $label => $params): ?>
                                    <?php $orderType = ($params['iOrderType'] == 'asc') ? '0' : '1'; ?>
                                    
                                    <?php if(osc_search_order() == $params['sOrder'] && osc_search_order_type() == $orderType): ?>
                    				    <option value="<?php echo osc_update_search_url($params); ?>" selected><?php echo $label; ?></option>
                                    <?php else: ?>
                    				    <option value="<?php echo osc_update_search_url($params); ?>"><?php echo $label; ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>					
        					</select>
        				</div>
                        
        				<div class="c_filter-view">
        					<div class="c_filter-view__item c_latest-view__box <?php if(osc_get_preference('default_show_items', 'marketplace_theme') == 'gallery'): ?>active<?php endif; ?>"><span></span></div>
        					<div class="c_filter-view__item c_latest-view__line <?php if(osc_get_preference('default_show_items', 'marketplace_theme') == 'list'): ?>active<?php endif; ?>"><span></span></div>
        				</div>
                        
        			</div>
        
        			<div class="c_list <?php if(osc_get_preference('default_show_items', 'marketplace_theme') == 'list'): ?>c_list-line<?php endif; ?>">
                        <?php osc_get_premiums(osc_get_preference('search_premium_num_ads', 'marketplace_theme')); ?>
                        
                        <?php if(osc_count_premiums()): ?>
                            <?php $i = 0; while(osc_has_premiums()): ?>
                                <div class="c_item" id="<?php if(function_exists('rupayments_premium_get_class_color')){echo rupayments_premium_get_class_color(osc_premium_id()); } ?>">
                					<div class="c_item-thumb">
                                        <?php if(osc_images_enabled_at_items() && osc_count_premium_resources()): ?>
                    					   <div class="c_item-photo"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_highlight(osc_premium_title()); ?>"></div>
                                        <?php else: ?>
                                            <div class="c_item-photo"><img style="min-height: auto;" src="<?php echo osc_current_web_theme_url('images/no_photo.gif') ; ?>" alt="<?php _e('No Photo', 'marketplace') ?>"></div>
                                        <?php endif; ?>
                                        
                                        <div class="c_item-favorite"></div>
                					</div>
                					<div class="c_item-info">
                                        <div class="c_item-ins">
                    						<a href="<?php echo osc_premium_url() ; ?>" class="c_item-title">
                                                <?php if(strlen(osc_premium_title()) > 25) echo mb_substr(osc_highlight(osc_premium_title()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_premium_title()); ?>
                                            </a>
                                            
                    						<div class="c_item-desc">
                                                <?php if(strlen(osc_premium_description()) > 25) echo mb_substr(osc_highlight(osc_premium_description()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_premium_description()); ?>
                                            </div>
                                            
                    						<p class="c_item-cat <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                                <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_premium_category_id()) . ".png")): ?>
                                                    <img border="0" style="position: relative;top: -5px;max-width: 40px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_premium_category_id()) . '.png');?>" />
                                                <?php endif; ?>
                                                <?php echo marketplace_category_root_name(osc_premium_category_id()); ?>
                                            </p>
                                            <div class="c_item-photos"><?php echo osc_count_premium_resources(); ?></div>
                    						<a href="<?php echo osc_premium_url() ; ?>" class="c_item-view"><?php _e('View item', 'marketplace') ?></a>
                                        </div>
                					</div>
                					<div class="c_item-addit">
                                        <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_premium_category_id())): ?>
                                            <div class="c_item-price"><?php echo osc_premium_formated_price(); ?></div>
                                        <?php endif; ?>
                                        
                						<a href="<?php echo osc_premium_url() ; ?>" class="c_item-more"><?php _e('Learn more', 'marketplace') ?></a>
                                        <div class="c_item-location"><?php echo osc_premium_city(); ?></div>
                					</div>
                				</div>
                                
                                <?php $i++; if($i > 20) break; ?>
                            <?php endwhile; ?>
                        <?php endif; ?>
                        
                        <?php if(osc_count_items()): ?>
                            <?php while(osc_has_items()): ?>
                				<div class="c_item" id="<?php if(function_exists('rupayments_get_class_color')){echo rupayments_get_class_color(osc_item_id()); } ?>">
                					<div class="c_item-thumb">
                                        <?php if(osc_images_enabled_at_items() && osc_count_item_resources()): ?>
                    					   <div class="c_item-photo"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_highlight(osc_item_title()); ?>"></div>
                                        <?php else: ?>
                                            <div class="c_item-photo"><img style="min-height: auto;" src="<?php echo osc_current_web_theme_url('images/no_photo.gif') ; ?>" alt="<?php _e('No Photo', 'marketplace') ?>"></div>
                                        <?php endif; ?>
                					</div>
                					<div class="c_item-info">
                                        <div class="c_item-ins">
                    						<a href="<?php echo osc_item_url() ; ?>" class="c_item-title">
                                                <?php if(strlen(osc_item_title()) > 25) echo mb_substr(osc_highlight(osc_item_title()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_title()); ?>
                                            </a>
                                            
                    						<div class="c_item-desc">
                                                <?php if(strlen(osc_item_description()) > 25) echo mb_substr(osc_highlight(osc_item_description()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_description()); ?>
                                            </div>
                                            
                    						<p class="c_item-cat <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                                <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_item_category_id()) . ".png")): ?>
                                                    <img border="0" style="position: relative;top: -5px;max-width: 40px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_item_category_id()) . '.png');?>" />
                                                <?php endif; ?>
                                                <?php echo marketplace_category_root_name(osc_item_category_id()); ?>
                                            </p>
                                            <div class="c_item-photos"><?php echo osc_count_item_resources(); ?></div>
                    						<a href="<?php echo osc_item_url() ; ?>" class="c_item-view"><?php _e('View item', 'marketplace') ?></a>
                                        </div>
                					</div>
                					<div class="c_item-addit">
                                        <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_item_category_id())): ?>
                                            <div class="c_item-price"><?php echo osc_item_formated_price(); ?></div>
                                        <?php endif; ?>
                                        
                						<a href="<?php echo osc_item_url() ; ?>" class="c_item-more"><?php _e('Learn more', 'marketplace') ?></a>
                                        <div class="c_item-location"><?php echo osc_item_city(); ?></div>
                					</div>
                				</div>
                            <?php endwhile; ?>
                                
                            <?php if(osc_list_total_pages() > 1): ?>
                               <div class="pagination">
                                   <?php echo osc_pagination_items(); ?>
                               </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <p><?php printf(__('There are no results matching %s', 'marketplace'), osc_search_pattern()); ?></p>
                        <?php endif; ?>
        			</div>
                    
                    <?php if ( osc_category_description($locale = "") != ''): ?>
            			<div class="c_single-box c_useful">
            				<div class="c_txt">
            					<p><?php echo osc_category_description($locale = ""); ?></p>
            				</div>
            			</div><!-- /c_useful -->
                    <?php endif; ?>
        		</div>
                
                <?php if(osc_get_preference('search_position', 'marketplace_theme') == 'right'): ?>
            		<aside class="c_side">
            			<div class="s_box s_catlist">
            				<div class="s_catlist-head"><?php echo osc_category_name(); ?></div>
            				<ul>
            					<?php marketplace_sidebar_category_search(osc_category_id()); ?>
            				</ul>
            			</div>
            
            			<?php osc_current_web_theme_path('inc.search.php'); ?>
            		</aside>
                <?php endif; ?>
        	</div>
        </main><!-- .main -->
        
        <?php if(osc_get_preference('ads_sp_un', 'marketplace_theme')): ?>
            <div class="ads-block">
                <?php echo osc_get_preference('ads_sp_un', 'marketplace_theme'); ?>
            </div>
        <?php endif; ?>
        
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>