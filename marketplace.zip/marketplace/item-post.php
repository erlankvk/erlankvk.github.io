<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
<head>
    <?php osc_current_web_theme_path('head.php'); ?>
</head>

<body>
<?php osc_current_web_theme_path('header.php'); ?>

<?php ItemForm::location_javascript(); ?>
<?php marketplace_validation_wrapper(); ?>

<div class="c_reg">
    <div class="c_reg-top">
        <div class="c_reg-head"><?php _e('Publish a listing', 'marketplace') ?></div>
        <?php if(!osc_logged_user_id()): ?>
            <p><?php _e('Create an account and get more features!', 'marketplace') ?>:</p>
            <p><a href="<?php echo osc_register_account_url (); ?>"><?php _e('Register', 'marketplace') ?></a></p>
        <?php endif; ?>
    </div>
    <div class="c_form c_reg-form">
        <form id="item-post" name="item" action="<?php echo osc_base_url(true);?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="item_add_post" />
            <input type="hidden" name="page" value="item" />

            <div class="c_form-label c_select s_search-select c_single-form__cat">
                <?php ItemForm::category_multiple_selects(null, null, __('Select a category', 'marketplace')); ?>
            </div>

            <?php if(osc_get_preference('item_fields_position', 'marketplace_theme') == 'after'):?>
                <div class="c_form-label c_form-hide-ico">
                    <?php ItemForm::plugin_post_item(); ?>
                </div>
            <?php endif; ?>

            <div class="c_form-label c_single-form__mess post_title">
                <?php ItemForm::title_input('title', osc_current_user_locale()); ?>
                <span class="c_form-placeholder"><?php _e('Title', 'marketplace') ?>*</span>
                <div class="c_form-count max_title" data-val="<?php echo osc_max_characters_per_title(); ?>"><?php echo osc_max_characters_per_title(); ?></div>
            </div>
            <div class="c_form-label c_single-form__mess post_desc">
                <?php ItemForm::description_textarea('description',osc_current_user_locale()); ?>
                <span class="c_form-placeholder"><?php _e('Description', 'marketplace') ?>*</span>
                <div class="c_form-count max_desc" data-val="<?php echo osc_max_characters_per_description(); ?>"><?php echo osc_max_characters_per_description(); ?></div>
            </div>

            <?php if( osc_images_enabled_at_items() ): ?>
                <div class="c_form-label c_single-form__upload">
                    <div class="c_form-upload__title"><?php _e('Add images', 'marketplace') ?></div>
                    <div class="c_form-upload__desc"><?php echo sprintf(__('You can upload up to %d pictures per listing', 'marketplace'), osc_max_images_per_item()); ?></div>
                    <div class="c_form-upload__desc"><?php echo sprintf(__('Max size %d Kb for each image', 'marketplace'), osc_max_size_kb()); ?></div>
                    <?php ItemForm::ajax_photos(); ?>
                </div>

            <?php endif; ?>

            <div class="c_form-label c_single-form__price">
                <?php ItemForm::price_input_text(); ?>
                <span class="c_form-placeholder"><?php _e('Price', 'marketplace') ?></span>

                <div class="c_select c_form-currency">
                    <?php ItemForm::currency_select(); ?>
                </div>
            </div>

            <div class="locations-block">
                <?php if(osc_get_preference('item_countries', 'marketplace_theme')): ?>
                    <div class="c_form-label c_select s_search-select c_single-form__location">
                        <?php ItemForm::country_select(osc_get_countries(), osc_user()); ?>
                    </div>
                <?php endif; ?>

                <?php if(osc_get_preference('item_location', 'marketplace_theme')): ?>
                    <div class="c_form-label c_select s_search-select c_single-form__location">
                        <?php ItemForm::region_select(osc_get_regions(), osc_user()); ?>
                    </div>
                    <div class="c_form-label c_select s_search-select c_single-form__location">
                        <?php ItemForm::city_select(osc_get_cities(osc_user_region()), osc_user()); ?>
                    </div>
                    <div class="c_form-label c_single-form__location">
                        <?php ItemForm::city_area_text(osc_user()); ?>
                        <span class="c_form-placeholder <?php if(osc_user_city_area()) echo 'active'; ?>"><?php _e('City Area', 'marketplace') ?></span>
                    </div>
                    <div class="c_form-label c_single-form__location">
                        <?php ItemForm::address_text(osc_user()); ?>
                        <span class="c_form-placeholder <?php if(osc_user_address()) echo 'active'; ?>"><?php _e('Address', 'marketplace') ?></span>
                    </div>
                <?php endif; ?>
            </div>

            <?php if(!osc_is_web_user_logged_in()): ?>
                <div class="c_form-label c_single-form__name">
                    <?php ItemForm::contact_name_text(); ?>
                    <span class="c_form-placeholder"><?php _e('Name', 'marketplace') ?></span>
                </div>
                <?php if( function_exists( "MyHoneyPot" )) { ?>
                    <?php MyHoneyPot(); ?>
                <?php } ?>
                <div class="c_form-label c_single-form__email">
                    <?php ItemForm::contact_email_text(); ?>
                    <span class="c_form-placeholder"><?php _e('E-mail', 'marketplace') ?>*</span>
                </div>

                <div class="c_reg-forgot">
                    <div class="c_reg-forgot__remember">
                        <label for="email-show">
                            <input type="checkbox" name="email-show" id="email-show">
                            <span class="c_reg-forgot__label"><?php _e('Show email on listing page', 'marketplace') ?></span>
                        </label>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(osc_get_preference('item_fields_position', 'marketplace_theme') == 'bottom'):?>
                <div class="c_form-label c_form-hide-ico">
                    <?php ItemForm::plugin_post_item(); ?>
                </div>
            <?php endif; ?>

            <div class="inp-captcha">
                <?php osc_show_recaptcha(); ?>
            </div>

            <div class="c_reg-btn c_public-btn centerbutton">
                <button type="submit"><i class="mp mp-ok"></i><?php _e('Publish', 'marketplace') ?></button>
            </div>
        </form>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#select_1').selectpicker();

        // $('select[id^="select_"]').change(function() {
        //     setTimeout(function(){
        //         $('select[id^="select_"]').selectpicker();
        //     }, 10);
        // });

        <?php if(osc_get_preference('item_countries', 'marketplace_theme')): ?>
        $('#countryId').change(function() {
            $('#regionId').selectpicker('refresh');
            $('#cityId').selectpicker('refresh');
        });

        $('.locations-block div.bootstrap-select').eq(1).click(function() {
            $('#regionId').selectpicker('refresh');
        });

        $('.locations-block div.bootstrap-select').eq(2).click(function() {
            $('#cityId').selectpicker('refresh');
        });
        <?php else: ?>
        $('#regionId').change(function() {
            $('#cityId').selectpicker('refresh');
        });

        $('.locations-block div.bootstrap-select').eq(1).click(function() {
            $('#cityId').selectpicker('refresh');
        });
        <?php endif; ?>

        $("#price").blur(function(event) {
            var price = $("#price").prop("value");
            <?php if(osc_locale_thousands_sep()!='') { ?>
            while(price.indexOf('<?php echo osc_esc_js(osc_locale_thousands_sep());  ?>')!=-1) {
                price = price.replace('<?php echo osc_esc_js(osc_locale_thousands_sep());  ?>', '');
            }
            <?php }; ?>
            <?php if(osc_locale_dec_point()!='') { ?>
            var tmp = price.split('<?php echo osc_esc_js(osc_locale_dec_point())?>');
            if(tmp.length>2) {
                price = tmp[0]+'<?php echo osc_esc_js(osc_locale_dec_point())?>'+tmp[1];
            }
            <?php }; ?>
            $("#price").prop("value", price);
        });
    });
</script>

<?php osc_current_web_theme_path('footer.php'); ?>
</body>
</html>