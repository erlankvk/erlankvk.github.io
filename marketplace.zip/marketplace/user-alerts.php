<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        
        <main class="m_box c_main c_kabinet">
        	<div class="m_inb">
        		<div class="c_cont">
        			
        			<div class="c_list c_list-line">
                        <?php if(osc_count_alerts()):?>
                            <?php while(osc_has_alerts()): ?>
                				<div class="c_item">
                					<div class="c_item-thumb">
                                        <?php if(osc_images_enabled_at_items() && osc_count_item_resources()): ?>
                    					   <div class="c_item-photo"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_highlight(osc_item_title()); ?>"></div>
                                        <?php else: ?>
                                            <div class="c_item-photo"><img style="min-height: auto;" src="<?php echo osc_current_web_theme_url('images/no_photo.gif') ; ?>" alt="<?php _e('No Photo', 'marketplace') ?>"></div>
                                        <?php endif; ?>
                                        
                                        <?php if(osc_item_is_premium()): ?>
                                            <div class="c_item-favorite"></div>
                                        <?php endif; ?>
                					</div>
                					<div class="c_item-info">
                						<a href="<?php echo osc_item_url() ; ?>" class="c_item-title">
                                            <?php if(strlen(osc_item_title()) > 25) echo mb_substr(osc_item_title(), 0, 23,'UTF-8') . '...'; else echo osc_item_title(); ?>
                                        </a>
                                        
                						<div class="c_item-desc">
                                            <?php if(strlen(osc_item_description()) > 25) echo mb_substr(osc_item_description(), 0, 23,'UTF-8') . '...'; else echo osc_item_description(); ?>
                                        </div>
                                        
                						<a href="<?php echo marketplace_category_url(marketplace_category_root(osc_item_category_id())); ?>" class="c_item-cat <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                            <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_item_category_id()) . ".png")): ?>
                                                <img border="0" style="position: relative;top: -5px;max-width: 40px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_item_category_id()) . '.png');?>" />
                                            <?php endif; ?>
                                            <?php echo marketplace_category_root_name(osc_item_category_id()); ?>
                                        </a>
                                        
                						<a href="<?php echo osc_item_url() ; ?>" class="c_item-view"><?php _e('View ad', 'marketplace') ?></a>
                					</div>
                					<div class="c_item-addit">
                                        <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_item_category_id())): ?>
                                            <div class="c_item-price"><?php echo osc_item_formated_price(); ?></div>
                                        <?php endif; ?>
                                        
                						<a href="<?php echo osc_item_url() ; ?>" class="c_item-more"><?php _e('Learn more', 'marketplace') ?></a>
                                        <div class="c_item-location"><?php echo osc_item_city(); ?></div>

                						<a onclick="javascript:return confirm('<?php echo osc_esc_js(__('This action can not be undone. Are you sure you want to continue?', 'marketplace')); ?>')" class="c_item-delete" href="<?php echo osc_user_unsubscribe_alert_url(); ?>"><?php _e('Delete this alert', 'marketplace') ?></a>
                					</div>
                				</div>
                            <?php endwhile; ?>
                            
                            <?php if(osc_list_total_pages() > 1): ?>
                               <div class="pagination">
                                   <?php echo osc_pagination_items(); ?>
                               </div>
                           <?php endif; ?>
                        <?php else: ?>
                            <?php _e('You do not have any alerts yet', 'marketplace'); ?>
                        <?php endif; ?>
        			</div>
        		</div>
        
        		<aside class="c_side">
        
        			<div class="s_box s_kabnav">
        				<ul>
                            <?php echo osc_private_user_menu(get_user_menu()); ?>
        				</ul>
        			</div>
        
        		</aside>
        	</div>
        </main><!-- .main -->
        
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>