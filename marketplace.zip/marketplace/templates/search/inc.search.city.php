<?php
/*
 * Copyright 2018 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<form class="nocsrf form" action="<?php echo osc_base_url(true); ?>" method="post">
	<input type="hidden" name="page" value="search"/>
		
    <div class="c_maincat-box">
        <div class="c_select c_maincat-box__select">
    		<select id="sCategory" class="search-select" data-size="7" name="sCategory">
                <option value=""><?php echo osc_esc_html(__('Select a category...', 'marketplace'));?></option>
                <?php foreach(Category::newInstance()->toTree() as $category): ?>
    				<option value="<?php echo $category['pk_i_id']?>"><?php echo $category['s_name']?></option>
    				
                    <?php if(isset($category['categories']) && is_array($category['categories']) && osc_get_preference('subcategories', 'marketplace_theme'))
    				        CategoryForm::subcategory_select($category['categories'], null, __('Select a category...', 'marketplace'), 2);
    				?>
    			<?php endforeach; ?>
            </select>
    	</div>
        
        <div class="c_select c_maincat-box__select">
            <?php marketplace_city_select('form-select-2') ; ?>
        </div>
        
        <div class="c_maincat-box__select c_maincat-box__search">
    		<input id="sPattern" type="text" name="sPattern" placeholder="<?php echo osc_esc_html(__(osc_get_preference('keyword_placeholder', 'marketplace_theme'))); ?>">
    		<input type="submit" value="">
    	</div>
    </div>    
</form>

<style>
.c_maincat-box__select {
    width: 30%;
    margin: 0;
}
</style>