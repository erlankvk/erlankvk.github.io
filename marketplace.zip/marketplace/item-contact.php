<?php if(osc_logged_user_id() != osc_user_id() && osc_logged_user_id()): ?>
	<div class="s_box s_contact">
		<div class="s_contact-head"><?php _e('Contact publisher', 'marketplace') ?></div>
		<div class="c_form s_contact-form">
            <ul id="error_list"></ul>
            <?php ContactForm::js_validation(); ?>
            
			<form id="contact_form" action="<?php echo osc_base_url(true); ?>" method="post" name="contact_form">
                <input type="hidden" name="action" value="contact_post" />
                <input type="hidden" name="page" value="item" />
                <input type="hidden" name="id" value="<?php echo osc_item_id(); ?>" />
                
				<div class="c_form-label c_single-form__user">
					<input id="yourName" type="text" name="yourName">
					<span class="c_form-placeholder"><?php _e('Your name', 'marketplace') ?></span>
				</div>
				<div class="c_form-label c_single-form__email">
					<input id="yourEmail" type="email" name="yourEmail">
					<span class="c_form-placeholder"><?php _e('Your e-mail', 'marketplace') ?></span>
				</div>
				<div class="c_form-label c_single-form__phone">
					<input id="phoneNumber" type="tel" name="phoneNumber">
					<span class="c_form-placeholder"><?php _e('Your phone', 'marketplace') ?></span>
				</div>
				<div class="c_form-label c_single-form__mess c_single-form__area">
					<textarea id="message" name="message"></textarea>
					<span class="c_form-placeholder"><?php _e('Comment', 'marketplace') ?></span>
				</div>
                
                <div class="inp-captcha">
                    <?php osc_show_recaptcha(); ?>
                </div>
                
                <?php osc_run_hook('item_contact_form', osc_item_id()); ?>
				<input type="submit" value="<?php _e('Send', 'marketplace') ?>">
			</form>
		</div>
	</div>
<?php elseif(osc_reg_user_can_contact() && !osc_is_web_user_logged_in()): ?>
    <div class="s_box s_contact">
        <p>
            <?php _e("You must log in or register a new account in order to contact the publisher", 'marketplace'); ?>
            
            <a href="<?php echo osc_user_login_url(); ?>" class="btn btn-primary"><?php _e('Login', 'marketplace'); ?></a>
            <a href="<?php echo osc_register_account_url(); ?>" class="btn btn-primary"><?php _e('Register', 'marketplace'); ?></a>
        </p>
    </div>
<?php endif; ?>