<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body>
        <?php osc_current_web_theme_path('header.php'); ?>
        
        <div class="m_box c_maincat">
        	<div class="m_inb">
                <?php osc_current_web_theme_path('templates/search/' . osc_get_preference('main_search', 'marketplace_theme') . '.php') ; ?> 
                
                <?php if(osc_get_preference('categoriesmain', 'marketplace_theme') && osc_count_categories()): ?>
                    <?php osc_goto_first_category(); ?>
                    <div class="c_maincat-list">
                        <?php while(osc_has_categories()): ?>
            			 <a href="<?php echo osc_search_category_url()?>" class="c_maincat-item <?php if(!file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_category_id()) . ".png")): ?>cat-no-img<?php endif; ?>">
                            <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_category_id()) . ".png")): ?>
                                <img border="0" style="display: block; width: 50px; margin: 15px auto 0;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_category_id()) . '.png');?>" />
                            <?php endif; ?>
                            <p><?php if(strlen(osc_category_name()) > 25) echo mb_substr(osc_category_name(), 0, 23,'UTF-8').'...'; else echo osc_category_name(); ?></p>
                         </a>
                        <?php endwhile; ?>
            		</div>
                <?php endif; ?>
        	</div>
        </div><!-- .maincat -->
        
        <?php if(osc_get_preference('ads_hp_un_categories', 'marketplace_theme')): ?>
            <div class="ads-block">
                <?php echo osc_get_preference('ads_hp_un_categories', 'marketplace_theme'); ?>
            </div>
        <?php endif; ?>
        
        <?php if(osc_get_preference('main_carousel', 'marketplace_theme') == 'popular'): ?>
            <?php $popular_items = marketplace_most_popular(osc_get_preference('carousel_num_ads', 'marketplace_theme')); ?>
            <?php View::newInstance()->_exportVariableToView('items', $popular_items);?>
            
            <?php if(osc_count_items()): ?>
                <section class="m_box c_popular">
                	<div class="m_inb">
                		<h2 class="c_head"><?php _e('Popular items', 'marketplace') ?></h2>
                		<div class="c_list c_list-slider">
                            <?php $i = 1; while(osc_has_items()): ?>
                    			<div class="c_item" id="<?php if(function_exists('rupayments_get_class_color')){echo rupayments_get_class_color(osc_item_id()); } ?>">
                    				<div class="c_item-thumb">
                                        <?php if(osc_images_enabled_at_items() && osc_count_item_resources()): ?>
                    					   <div class="c_item-photo"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_highlight(osc_item_title()); ?>"></div>
                                        <?php else: ?>
                                            <div class="c_item-photo"><img style="min-height: auto;" src="<?php echo osc_current_web_theme_url('images/no_photo.gif') ; ?>" alt="<?php _e('No Photo', 'marketplace') ?>"></div>
                                        <?php endif; ?>
                    				</div>
                    				<div class="c_item-info">
                    					<div class="c_item-ins">
                    						<a href="<?php echo osc_item_url() ; ?>" class="c_item-title">
                                                <?php if(strlen(osc_item_title()) > 25) echo mb_substr(osc_highlight(osc_item_title()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_title()); ?>
                                            </a>
                                            
                    						<div class="c_item-desc">
                                                <?php if(strlen(osc_item_description()) > 25) echo mb_substr(osc_highlight(osc_item_description()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_description()); ?>
                                            </div>
                    						<p class="c_item-cat <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                                <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_item_category_id()) . ".png")): ?>
                                                    <img border="0" style="position: relative;top: -5px;max-width: 40px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_item_category_id()) . '.png');?>" />
                                                <?php endif; ?>
                                                <?php echo marketplace_category_root_name(osc_item_category_id()); ?>
                                            </p>
                    						<div class="c_item-photos"><?php echo osc_count_item_resources(); ?></div>
                    						<a href="<?php echo osc_item_url() ; ?>" class="c_item-view"><?php _e('View item', 'marketplace') ?></a>
                    					</div>
                    				</div>
                    				<div class="c_item-addit">
                                        <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_item_category_id())): ?>
                                            <div class="c_item-price"><?php echo osc_item_formated_price(); ?></div>
                                        <?php endif; ?>
                                        
                    					<a href="<?php echo osc_item_url() ; ?>" class="c_item-more"><?php _e('Learn more', 'marketplace') ?></a>
										<?php if(osc_item_city()): ?>
                    					<div class="c_item-location"><?php echo osc_item_city(); ?></div>
										<?php endif; ?>
                    				</div>
                    			</div>
                                
                                <?php $i++; ?>
                                <?php if($i > osc_get_preference('carousel_num_ads', 'marketplace_theme')) break; ?>
                            <?php endwhile; ?>
                		</div>
                
                		<div class="c_ads c_ads-bottom">
                			<div class="c_ads-item"></div>
                			<div class="c_ads-item"></div>
                		</div>
						<button class="prev slick-prev"><?php _e('Previous', 'marketplace') ?></button>
<button class="next slick-next"><?php _e('Next', 'marketplace') ?></button>
                	</div>
                </section><!-- .popular -->
                <?php osc_reset_items(); ?>
            <?php endif; ?>
        <?php elseif(osc_get_preference('main_carousel', 'marketplace_theme') == 'premium'): ?>
            <?php osc_get_premiums(osc_get_preference('carousel_num_ads', 'marketplace_theme')); ?>
            
            <?php if(osc_count_premiums()): ?>
                <section class="m_box c_premium">
                	<div class="m_inb">
                		<h2 class="c_head"><?php _e('Premium items', 'marketplace') ?></h2>
                		<div class="c_list c_list-slider">
                
                            <?php $i = 1; while(osc_has_premiums()): ?>
                    			<div class="c_item" id="<?php if(function_exists('rupayments_premium_get_class_color')){echo rupayments_premium_get_class_color(osc_premium_id()); } ?>">
                    				<div class="c_item-thumb">
                                        <?php if(osc_images_enabled_at_items() && osc_count_premium_resources()): ?>
                    					   <div class="c_item-photo"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_highlight(osc_premium_title()); ?>"></div>
                                        <?php else: ?>
                                            <div class="c_item-photo"><img style="min-height: auto;" src="<?php echo osc_current_web_theme_url('images/no_photo.gif') ; ?>" alt="<?php _e('No Photo', 'marketplace') ?>"></div>
                                        <?php endif; ?>
                    					<div class="c_item-favorite"></div>
                    				</div>
                    				<div class="c_item-info">
                    					<div class="c_item-ins">
                    						<a href="<?php echo osc_premium_url() ; ?>" class="c_item-title">
												 <?php if(strlen(osc_premium_title()) > 25) echo mb_substr(osc_highlight(osc_premium_title()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_premium_title()); ?>
                                            </a>
                                            
                    						<div class="c_item-desc">
												<?php if(strlen(osc_premium_description()) > 25) echo mb_substr(osc_highlight(osc_premium_description()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_premium_description()); ?>
                                            </div>
                    						<p class="c_item-cat <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                                <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_premium_category_id()) . ".png")): ?>
                                                    <img border="0" style="position: relative;top: -5px;max-width: 40px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_premium_category_id()) . '.png');?>" />
                                                <?php endif; ?>
                                                <?php echo marketplace_category_root_name(osc_premium_category_id()); ?>
                                            </p>
                    						<div class="c_item-photos"><?php echo osc_count_premium_resources(); ?></div>
                    						<a href="<?php echo osc_premium_url() ; ?>" class="c_item-view"><?php _e('View item', 'marketplace') ?></a>
                    					</div>
                    				</div>
                    				<div class="c_item-addit">
                                        <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_premium_category_id())): ?>
                                            <div class="c_item-price"><?php echo osc_premium_formated_price(); ?></div>
                                        <?php endif; ?>
                                        
                    					<a href="<?php echo osc_premium_url() ; ?>" class="c_item-more"><?php _e('Learn more', 'marketplace') ?></a>
										<?php if(osc_premium_city()): ?>
                    					<div class="c_item-location"><?php echo osc_premium_city(); ?></div>
										<?php endif; ?>
                    				</div>
                    			</div>
                            
                                <?php $i++; ?>
                                <?php if($i > osc_get_preference('carousel_num_ads', 'marketplace_theme')) break; ?>
                            <?php endwhile; ?>
                		</div>
<button class="prev slick-prev"><?php _e('Previous', 'marketplace') ?></button>
<button class="next slick-next"><?php _e('Next', 'marketplace') ?></button>
                	</div>
                </section><!-- .premium -->
            <?php endif; ?>
        <?php endif; ?>
        
        <?php if(osc_get_preference('middle_block_status', 'marketplace_theme')): ?>
        <section class="m_box c_whychoose">
        	<div class="m_inb">
        		<h2 class="c_head"><?php echo osc_get_preference('first_md_text', 'marketplace_theme'); ?></h2>
        		<div class="c_whychoose-desc"><?php echo osc_get_preference('first_md_description', 'marketplace_theme'); ?></div>
        		<div class="c_whychoose-list">
                    <?php if(osc_get_preference('first_md_list', 'marketplace_theme')): ?>
                        <div class="c_whychoose-item c_whychoose-item__sell"><?php echo osc_get_preference('first_md_list', 'marketplace_theme'); ?></div>
                    <?php endif; ?>
                    
                    <?php if(osc_get_preference('second_md_list', 'marketplace_theme')): ?>
                        <div class="c_whychoose-item c_whychoose-item__meet"><?php echo osc_get_preference('second_md_list', 'marketplace_theme'); ?></div>
                    <?php endif; ?>
                    
                    <?php if(osc_get_preference('last_md_list', 'marketplace_theme')): ?>
                        <div class="c_whychoose-item c_whychoose-item__sell"><?php echo osc_get_preference('last_md_list', 'marketplace_theme'); ?></div>
                    <?php endif; ?>
        		</div>
        		<div class="c_whychoose-bot"><?php echo osc_get_preference('last_md_text', 'marketplace_theme'); ?></div>
        		<a href="<?php echo osc_item_post_url(); ?>" class="c_btn c_whychoose-btn"><?php _e('Publish your ad', 'marketplace') ?></a>
        	</div>
        </section><!-- .whychoose -->
        <?php endif; ?>
        
        <?php if(osc_get_preference('ads_hp_top_latest_items', 'marketplace_theme')): ?>
            <div class="ads-block">
                <?php echo osc_get_preference('ads_hp_top_latest_items', 'marketplace_theme'); ?>
            </div>
        <?php endif; ?>
        
        <?php osc_reset_latest_items(); ?>           
        <?php if(osc_count_latest_items()): ?>
            <section class="m_box c_latest">
            	<div class="m_inb">
            		<div class="c_ads c_ads-top">
            			<div class="c_ads-item"></div>
            			<div class="c_ads-item"></div>
            		</div>
            		<h2 class="c_head"><?php _e('Latest Listings', 'marketplace') ?></h2>
            		<div class="c_filter-view">
            			<div class="c_filter-view__item c_latest-view__box active"><span></span></div>
            			<div class="c_filter-view__item c_latest-view__line"><span></span></div>
            		</div>
            		<div class="c_list">
            			<?php $i = 1; while(osc_has_latest_items()): ?>
                			<div class="c_item" id="<?php if(function_exists('rupayments_get_class_color')){echo rupayments_get_class_color(osc_item_id()); } ?>">
                				<div class="c_item-thumb">
                                    <?php if(osc_images_enabled_at_items() && osc_count_item_resources()): ?>
                					   <div class="c_item-photo"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_highlight(osc_item_title()); ?>"></div>
                                    <?php else: ?>
                                        <div class="c_item-photo"><img style="min-height: auto;" src="<?php echo osc_current_web_theme_url('images/no_photo.gif') ; ?>" alt="<?php _e('No Photo', 'marketplace') ?>"></div>
                                    <?php endif; ?>
                				</div>
                				<div class="c_item-info">
                					<div class="c_item-ins">
                						<a href="<?php echo osc_item_url() ; ?>" class="c_item-title">
                                            <?php if(strlen(osc_item_title()) > 25) echo mb_substr(osc_highlight(osc_item_title()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_title()); ?>
                                        </a>
                                        
                						<div class="c_item-desc">
                                            <?php if(strlen(osc_item_description()) > 25) echo mb_substr(osc_highlight(osc_item_description()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_description()); ?>
                                        </div>
                						<p class="c_item-cat <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                            <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_item_category_id()) . ".png")): ?>
                                                <img border="0" style="position: relative;top: -5px;max-width: 40px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_item_category_id()) . '.png');?>" />
                                            <?php endif; ?>
                                            <?php echo marketplace_category_root_name(osc_item_category_id()); ?>
                                        </p>
                						<div class="c_item-photos"><?php echo osc_count_item_resources(); ?></div>
                						<a href="<?php echo osc_item_url() ; ?>" class="c_item-view"><?php _e('View item', 'marketplace') ?></a>
                					</div>
                				</div>
                				<div class="c_item-addit">
                                    <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_item_category_id())): ?>
                                        <div class="c_item-price"><?php echo osc_item_formated_price(); ?></div>
                                    <?php endif; ?>
                                    
                					<a href="<?php echo osc_item_url() ; ?>" class="c_item-more"><?php _e('Learn more', 'marketplace') ?></a>
									<?php if(osc_item_city()): ?>
                					<div class="c_item-location"><?php echo osc_item_city(); ?></div>
									<?php endif; ?>
                				</div>
                			</div>
                            
                            <?php $i++; ?>
                            <?php if($i > osc_get_preference('lib_num_ads', 'marketplace_theme')) break; ?>
                        <?php endwhile; ?>
                        
            		</div>
            
            		<a href="<?php echo osc_search_show_all_url();?>" class="c_btn c_latest-btn"><?php _e('More Listing', 'marketplace') ?></a>
            
            		<div class="c_ads c_ads-bottom">
            			<div class="c_ads-item"></div>
            			<div class="c_ads-item"></div>
            		</div>
            	</div>
            </section><!-- .latest -->
        <?php endif; ?>
        
        <?php if(osc_get_preference('ads_hp_un_latest_items', 'marketplace_theme')): ?>
            <div class="ads-block">
                <?php echo osc_get_preference('ads_hp_un_latest_items', 'marketplace_theme'); ?>
            </div>
        <?php endif; ?>
        
        <?php if(osc_get_preference('main_map', 'marketplace_theme')): ?>
            <?php osc_current_web_theme_path('templates/map/main_map.php') ; ?>
        <?php endif; ?>
        <?php if(osc_get_preference('main_carousel2', 'marketplace_theme') == 'popular'): ?>
            <?php $popular_items = marketplace_most_popular(osc_get_preference('carousel_num_ads', 'marketplace_theme')); ?>
            <?php View::newInstance()->_exportVariableToView('items', $popular_items);?>
            
            <?php if(osc_count_items()): ?>
                <section class="m_box c_popular box2">
                	<div class="m_inb">
                		<h2 class="c_head"><?php _e('Popular items', 'marketplace') ?></h2>
                		<div class="c_list c_list-slider2">
                            <?php $i = 1; while(osc_has_items()): ?>
                    			<div class="c_item" id="<?php if(function_exists('rupayments_get_class_color')){echo rupayments_get_class_color(osc_item_id()); } ?>">
                    				<div class="c_item-thumb">
                                        <?php if(osc_images_enabled_at_items() && osc_count_item_resources()): ?>
                    					   <div class="c_item-photo"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_highlight(osc_item_title()); ?>"></div>
                                        <?php else: ?>
                                            <div class="c_item-photo"><img style="min-height: auto;" src="<?php echo osc_current_web_theme_url('images/no_photo.gif') ; ?>" alt="<?php _e('No Photo', 'marketplace') ?>"></div>
                                        <?php endif; ?>
                    				</div>
                    				<div class="c_item-info">
                    					<div class="c_item-ins">
                    						<a href="<?php echo osc_item_url() ; ?>" class="c_item-title">
                                                <?php if(strlen(osc_item_title()) > 25) echo mb_substr(osc_highlight(osc_item_title()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_title()); ?>
                                            </a>
                                            
                    						<div class="c_item-desc">
                                                <?php if(strlen(osc_item_description()) > 25) echo mb_substr(osc_highlight(osc_item_description()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_description()); ?>
                                            </div>
                    						<p class="c_item-cat <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                                <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_item_category_id()) . ".png")): ?>
                                                    <img border="0" style="position: relative;top: -5px;max-width: 40px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_item_category_id()) . '.png');?>" />
                                                <?php endif; ?>
                                                <?php echo marketplace_category_root_name(osc_item_category_id()); ?>
                                            </p>
                    						<div class="c_item-photos"><?php echo osc_count_item_resources(); ?></div>
                    						<a href="<?php echo osc_item_url() ; ?>" class="c_item-view"><?php _e('View item', 'marketplace') ?></a>
                    					</div>
                    				</div>
                    				<div class="c_item-addit">
                                        <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_item_category_id())): ?>
                                            <div class="c_item-price"><?php echo osc_item_formated_price(); ?></div>
                                        <?php endif; ?>
                                        
                    					<a href="<?php echo osc_item_url() ; ?>" class="c_item-more"><?php _e('Learn more', 'marketplace') ?></a>
										<?php if(osc_item_city()): ?>
                    					<div class="c_item-location"><?php echo osc_item_city(); ?></div>
										<?php endif; ?>
                    				</div>
                    			</div>
                                
                                <?php $i++; ?>
                                <?php if($i > osc_get_preference('carousel_num_ads', 'marketplace_theme')) break; ?>
                            <?php endwhile; ?>
                		</div>
<button class="prev2 slick-prev"><?php _e('Previous', 'marketplace') ?></button>
<button class="next2 slick-next"><?php _e('Next', 'marketplace') ?></button>
                	</div>
                </section><!-- .popular -->
                <?php osc_reset_items(); ?>
            <?php endif; ?>
        <?php elseif(osc_get_preference('main_carousel2', 'marketplace_theme') == 'premium' && osc_has_premiums()): ?>
            <section class="m_box c_premium box2">
            	<div class="m_inb">
            		<h2 class="c_head"><?php _e('Premium items', 'marketplace') ?></h2>
            		<div class="c_list c_list-slider2">
            
            			<?php $i = 1; while(osc_has_premiums()): ?>
                			<div class="c_item" id="<?php if(function_exists('rupayments_premium_get_class_color')){echo rupayments_premium_get_class_color(osc_premium_id()); } ?>">
                				<div class="c_item-thumb">
                                    <?php if(osc_images_enabled_at_items() && osc_count_premium_resources()): ?>
                					   <div class="c_item-photo"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_highlight(osc_premium_title()); ?>"></div>
                                    <?php else: ?>
                                        <div class="c_item-photo"><img style="min-height: auto;" src="<?php echo osc_current_web_theme_url('images/no_photo.gif') ; ?>" alt="<?php _e('No Photo', 'marketplace') ?>"></div>
                                    <?php endif; ?>
                					<div class="c_item-favorite"></div>
                				</div>
                				<div class="c_item-info">
                					<div class="c_item-ins">
                						<a href="<?php echo osc_premium_url() ; ?>" class="c_item-title">
                                            <?php if(strlen(osc_premium_title()) > 25) echo mb_substr(osc_premium_title(), 0, 23,'UTF-8') . '...'; else echo osc_premium_title(); ?>
                                        </a>
                                        
                						<div class="c_item-desc">
                                            <?php if(strlen(osc_premium_category_description()) > 25) echo mb_substr(osc_premium_category_description(), 0, 23,'UTF-8') . '...'; else echo osc_premium_category_description(); ?>
                                        </div>
                						<p class="c_item-cat <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                            <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_premium_category_id()) . ".png")): ?>
                                                <img border="0" style="position: relative;top: -5px;max-width: 40px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_premium_category_id()) . '.png');?>" />
                                            <?php endif; ?>
                                            <?php echo marketplace_category_root_name(osc_premium_category_id()); ?>
                                        </p>
                						<div class="c_item-photos"><?php echo osc_count_premium_resources(); ?></div>
                						<a href="<?php echo osc_premium_url() ; ?>" class="c_item-view"><?php _e('View item', 'marketplace') ?></a>
                					</div>
                				</div>
                				<div class="c_item-addit">
                                    <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_premium_category_id())): ?>
                                        <div class="c_item-price"><?php echo osc_premium_formated_price(); ?></div>
                                    <?php endif; ?>
                                    
                					<a href="<?php echo osc_premium_url() ; ?>" class="c_item-more"><?php _e('Learn more', 'marketplace') ?></a>
									<?php if(osc_premium_city()): ?>
                					<div class="c_item-location"><?php echo osc_premium_city(); ?></div>
									 <?php endif; ?>
                				</div>
                			</div>
                        
                            <?php $i++; ?>
                            <?php if($i > osc_get_preference('carousel_num_ads', 'marketplace_theme')) break; ?>
                        <?php endwhile; ?>
            		</div>
					<button class="prev2 slick-prev"><?php _e('Previous', 'marketplace') ?></button>
<button class="next2 slick-next"><?php _e('Next', 'marketplace') ?></button>
            	</div>
            </section><!-- .premium -->
        <?php endif; ?>
        <?php if(osc_get_preference('bottom_block_status', 'marketplace_theme')): ?>
        <div class="m_box c_wwdev">
        	<div class="m_inb">
                <?php if(osc_get_preference('h2_left_bm_text', 'marketplace_theme') && osc_get_preference('subtitle_left_bm_text', 'marketplace_theme')): ?>
            		<div class="c_wwdev-item c_wwdev-item__info">
            			<div class="c_wwdev-item__title"><?php echo osc_get_preference('h2_left_bm_text', 'marketplace_theme'); ?></div>
            			<?php echo osc_get_preference('subtitle_left_bm_text', 'marketplace_theme'); ?>
            		</div>
                <?php endif; ?>
                
                <?php if(osc_get_preference('h2_right_bm_text', 'marketplace_theme') && osc_get_preference('subtitle_right_bm_text', 'marketplace_theme')): ?>
            		<div class="c_wwdev-item c_wwdev-item__preim">
            			<div class="c_wwdev-item__title"><?php echo osc_get_preference('h2_right_bm_text', 'marketplace_theme'); ?></div>
            			<?php echo osc_get_preference('subtitle_right_bm_text', 'marketplace_theme'); ?>
            		</div>
                <?php endif; ?>
        	</div>
        </div><!-- .wwdev -->
        <?php endif; ?>
        
        <?php if(osc_get_preference('main_brands_block_status', 'marketplace_theme')): ?>
            <div class="m_box c_partner">
            	<div class="m_inb">
            		<div class="c_partner-list">
                        <?php for($i = 1; $i <= 6; $i++): ?>
                            <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/partner" . $i . ".jpg")): ?>
                                <div class="c_partner-item">
                    				<img src="<?php echo osc_current_web_theme_url("images/partner" . $i . ".jpg");?>" alt="partner">
                    			</div>
                            <?php endif; ?>
                        <?php endfor; ?>
            		</div>
            	</div>
            </div><!-- .partner -->
        <?php endif; ?>
        
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>