<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        
        <div class="c_reg">
        	<div class="c_reg-top">
        		<div class="c_reg-head"><?php _e("Oops! Page not found.", 'marketplace') ?></div>
        		<?php _e("Let us help you, we have got a few tips for you to find it.", 'marketplace') ?>
        	</div>
        	<div class="c_form c_reg-form">
        		<form action="<?php echo osc_base_url(true) ; ?>" method="get">
                    <input type="hidden" name="page" value="search" />
                    
        			<div class="c_form-label c_single-form__subject">
        				<input type="text" name="sPattern"  id="query" value="" />
        				<span class="c_form-placeholder"><?php _e('Search...', 'marketplace') ?></span>
        			</div>
                    
        			<div class="c_reg-btn c_forgot-btn">
        				<input type="submit" value="<?php _e('Search', 'marketplace') ?>">
        			</div>
        		</form>
        	</div>
        </div>
        
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>