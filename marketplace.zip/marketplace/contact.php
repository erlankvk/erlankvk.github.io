<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        
        <?php ContactForm::js_validation(); ?>
        <?php marketplace_validation_wrapper(); ?>
        
        <div class="c_reg">
        	<div class="c_reg-top">
        		<div class="c_reg-head"><?php _e('Contact us', 'marketplace') ?></div>
        		<?php _e("Write to us and leave your contact details. We will contact you as soon as we can.", 'marketplace') ?>
        	</div>
        	<div class="c_form c_reg-form">
        		<form action="<?php echo osc_base_url(true); ?>" method="post" name="contact_form" id="contact">
                    <input type="hidden" name="page" value="contact" />
                    <input type="hidden" name="action" value="contact_post" />
                    
        			<div class="c_form-label c_single-form__subject">
        				<input id="subject" type="text" name="subject">
        				<span class="c_form-placeholder"><?php _e('Subject', 'marketplace') ?></span>
        			</div>
        			<div class="c_form-label c_single-form__mess">
        				<textarea id="message" name="message"></textarea>
        				<span class="c_form-placeholder"><?php _e('Comment', 'marketplace') ?></span>
        			</div>
        			<div class="c_form-label c_single-form__user">
        				<input id="yourName" type="text" name="yourName">
        				<span class="c_form-placeholder"><?php _e('Name', 'marketplace') ?></span>
        			</div>
					<?php if( function_exists( "MyHoneyPot" )) { ?>		
			<?php MyHoneyPot(); ?>		
		<?php } ?>    
        			<div class="c_form-label c_single-form__email">
        				<input id="yourEmail" type="email" name="yourEmail">
        				<span class="c_form-placeholder"><?php _e('E-mail', 'marketplace') ?></span>
        			</div>
                    
                    <div class="inp-captcha">
                        <?php osc_show_recaptcha(); ?>
                    </div>
                    
        			<div class="c_reg-btn c_forgot-btn centerbutton">
        				<button type="submit"><i class="mp mp-c"></i><?php _e('Send', 'marketplace') ?></button>
        			</div>
                    
                    <?php osc_run_hook('admin_contact_form'); ?>
        		</form>
        	</div>
        </div>
        
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>