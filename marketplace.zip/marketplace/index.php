<?php
/*
Theme Name: Osclass Marketplace Premium Theme
Theme URI: https://osclass-pro.com
Description: Easy flat responsive osclass theme for any device with unique design and powerful functions.
Version: 1.1.2
Author: OSCLASS-PRO.COM
Author URI: https://osclass-pro.com
Widgets: footer1, footer2, footer3
Theme update URI: marketplace
*/

function marketplace_theme_info() {
    return array(
        'name'        => 'marketplace',
        'version'     => '1.1.2',
        'description' => 'Easy flat responsive osclass theme for any device with unique design and powerful functions.',
        'author_name' => 'osclass-pro.com',
        'author_url'  => 'https://osclass-pro.com/',
        'locations'   => array('header', 'footer')
    );
}
?>