<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
		 <meta name="robots" content="noindex, nofollow" />
        <meta name="googlebot" content="noindex, nofollow" />
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        					<div class="forcemessages-inline">
	<?php osc_show_flash_message(); ?>
</div>
<div class="c_reg">
        <div class="c_form c_reg-form">
            <div class="inner">
                <h1><?php _e('Recover your password', 'eva'); ?></h1>
                <form action="<?php echo osc_base_url(true); ?>" method="post" >
                    <input type="hidden" name="page" value="login" />
                    <input type="hidden" name="action" value="forgot_post" />
                    <input type="hidden" name="userId" value="<?php echo osc_esc_html(Params::getParam('userId')); ?>" />
                    <input type="hidden" name="code" value="<?php echo osc_esc_html(Params::getParam('code')); ?>" />
                    <div class="c_reg-forgot">
                        <div class="c_form-label c_single-form__pass">                        
                            <input type="password" name="new_password" value="" />
							<label for="new_email" class="c_form-placeholder"><?php _e('New password', 'marketplace'); ?></label>
                        </div>
                        <div class="c_form-label c_single-form__pass">
						<input type="password" name="new_password2" value="" />
                            <label for="new_email" class="c_form-placeholder"><?php _e('Repeat new password', 'marketplace'); ?></label>
                        </div>
                        <button type="submit"><?php _e('Change password', 'marketplace'); ?></button>
                    </div>
                </form>
            </div></div>
        </div></div><div style="clear:both"></div>	
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>