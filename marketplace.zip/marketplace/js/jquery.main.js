jQuery(document).ready(function($) {

// lightbox
	$('.c_thumb-big a').lightbox();

// nav active
  $('.h_nav-btn').on('click', function(event) {
    event.preventDefault();
    $('.h_nav').toggleClass('active');
  });
  $(document).mouseup(function (e){
    var div = $(".h_nav");
    if (!div.is(e.target) && div.has(e.target).length === 0) {
      div.removeClass('active');
    }
  });

// search active
  $('.h_search-btn').on('click', function(event) {
    event.preventDefault();
    $('.h_search').toggleClass('active');
  });
  $(document).mouseup(function (e){
    var div = $(".h_search");
    if (!div.is(e.target) && div.has(e.target).length === 0) {
      div.removeClass('active');
    }
  });

// lang active
  $('.h_lang-head').on('click', function(event) {
    event.preventDefault();
    $('.h_lang').toggleClass('active');
  });
  $(document).mouseup(function (e){
    var div = $(".h_lang");
    if (!div.is(e.target) && div.has(e.target).length === 0) {
      div.removeClass('active');
    }
  });

// selectpicker
  $('select').selectpicker({
        noneSelectedText : ''
    });

//search box
  $('.s_search-head').on('click', function(event) {
    event.preventDefault();
    $(this).parents('.s_search-box').toggleClass('s_search-box__active');
  });

// Slider
	$('.c_list-slider').slick({
		slidesToShow: 4, slidesToScroll: 1,  autoplay: true, autoplaySpeed: 8000, prevArrow: $('.prev'),nextArrow: $('.next'),
    responsive: [
      { breakpoint: 1000, settings: { slidesToShow: 3 } },
      { breakpoint: 700, settings: { slidesToShow: 2 } },
      { breakpoint: 400, settings: { slidesToShow: 1 } }
    ]
	});
		$('.c_list-slider2').slick({
		slidesToShow: 4, slidesToScroll: 1,  autoplay: true, autoplaySpeed: 8000, prevArrow: $('.prev2'),nextArrow: $('.next2'),
    responsive: [
      { breakpoint: 1000, settings: { slidesToShow: 3 } },
      { breakpoint: 700, settings: { slidesToShow: 2 } },
      { breakpoint: 400, settings: { slidesToShow: 1 } }
    ]
	});

// Action
	$('.c_thumb-big').slick({
    slidesToShow: 1, slidesToScroll: 1, arrows: false, autoplay: true, autoplaySpeed: 8000, 
    fade: true, asNavFor: '.c_thumb-gallery', adaptiveHeight: true
  });
  $('.c_thumb-gallery').slick({
    slidesToShow: 6, slidesToScroll: 1, arrows: false, autoplay: true, autoplaySpeed: 8000, asNavFor: '.c_thumb-big', 
    focusOnSelect: true,
    responsive: [
      { breakpoint: 1100, settings: { slidesToShow: 5 } },
      { breakpoint: 900, settings: { slidesToShow: 4 } },
      { breakpoint: 600, settings: { slidesToShow: 3 } },
      { breakpoint: 400, settings: { slidesToShow: 2 } }
    ]
  });

// tabs
  $('ul.tabs__caption').each(function() {
    $(this).find('li').each(function(i) {
      $(this).click(function(){
        $(this).addClass('active').siblings().removeClass('active')
          .closest('div.tabs').find('div.tabs__content').removeClass('active').eq(i).addClass('active');
      });
    });
  });

// change item view on list
  $('.c_filter-view__item').on('click', function(event) {
    event.preventDefault();
    $(this).addClass('active').siblings().removeClass('active');
    let list = $(this).parents('.m_box').find('.c_list');
    if( $(this).hasClass('c_latest-view__line') ) {
      list.addClass('c_list-line');
    } else {
      list.removeClass('c_list-line');
    }
  });

  $('.c_whychoose').parallax({
    imageSrc: '/oc-content/themes/marketplace/images/bg-whychoose.jpg',
    speed: 0.1
  });

  $('.c_wwdev').parallax({
    imageSrc: '/oc-content/themes/marketplace/images/bg-wwdev.jpg',
    speed: 0.1
  });

// Range slider
  var priceMin = $('#sPriceMin').val(),
      priceMax = $('#sPriceMax').val();
      
  if(!parseInt(priceMin)) priceMin = 0;
  if(!parseInt(priceMax)) priceMax = 10000000;
      
  $("#slider-range").slider({
    range: true,
    orientation: "horizontal",
    min: 0,
    max: 10000000,
    values: [priceMin, priceMax],
    step: 100,

    slide: function (event, ui) {
      if (ui.values[0] == ui.values[1]) {
        return false;
      }
      
      $("#sPriceMin").val(ui.values[0]);
      $("#sPriceMax").val(ui.values[1]);
    }
  });

// input focus
  $(".c_form input, .c_form textarea").focus(function() {
    $(this).siblings('.c_form-placeholder').addClass('active');
  });

  $(".c_form input, .c_form textarea").focusout(function() {
    if( !$(this).val() ) {
      $(this).siblings('.c_form-placeholder').removeClass('active');
    }
  });
  
  $('.inp-counter textarea, .c_single-form__mess input, .c_single-form__mess textarea').keyup(function(e){
    e.preventDefault();
    var val = +$(this).val().length;
    $(this).siblings('.c_form-count').html(+$(this).siblings('.c_form-count').attr('data-val') - val);
  });

// search box mobile hide
  function serchBoxOnMobile() {
    let doc_w = $(document).width();
    if( doc_w < 600 ) {
      $('.s_search-box__mobile').each(function() {
        if( $(this).hasClass('s_search-box__active') ) {
          $(this).removeClass('s_search-box__active');
        } else {
          $(this).addClass('s_search-box__active');
        }
      });
    }
  }
  serchBoxOnMobile();
  $( window ).resize( serchBoxOnMobile );

// sticked side box
if(parseInt($('.m_inb').width()) > 800) {
 if( $('.side_fix').length && $('.c_related').length ) {
    var $window = $( window ),
        $target = $( ".side_fix" ),
        $bottom = $( '.c_related' ),
        $top = $target.offset().top,
        $width = $target.width();
        $height = $target.outerHeight(),
        $bottom = $bottom.offset().top;
    $window.on( 'scroll', function () {

      var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      if ( scrollTop > $top && scrollTop + $height < $bottom ) {
        $target.css( {
          position : 'fixed',
          top : '20px',
          width : $width,
        } );
      } else if ( scrollTop > $top && scrollTop + $height > $bottom ) {
        var top = $bottom - scrollTop - $height;

        if(parseInt($('#item-block').height()) < 1450) {
            $target.css( {
              top : top
            } );
        }
        else {
            $target.css( {
              position : 'fixed',
              top : top,
            } );
        }
        
      } else {
        $target.attr( 'style', '' );
      }
    } );
  }
  }

// scroll to
	$("body").on('click', '.goto', function(e){
		var scrollTo = $(this).data('scroll');
		$('html,body').stop().animate({ scrollTop: $('#'+scrollTo).offset().top }, 1000);
		e.preventDefault();
	});

// Popup

  $('.overlay, .popup-close').on('click', function(){
    $('.popup').fadeOut(); 
    $('.overlay').fadeOut();
  });
  $('.action').on('click', function(){
    var event = $(this).data('event'),
    eventTitle = $(this).data('name');
    $('input[name="input_type"]').val(eventTitle);
    $('.overlay').fadeIn();
    $('.popup-' + event).centered_popup(); 
    $('.popup-' + event).fadeIn(); 
    return false;
  });
  
  $('body').on('click', 'a.ico-close', function(e){
    e.preventDefault();
    $(this).parents('div#flashmessage').fadeOut(200);
  });  
});