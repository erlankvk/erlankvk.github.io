<?php
/*
 * Copyright 2021 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<title><?php echo meta_title(); ?></title>
<meta name="title" content="<?php echo osc_esc_html(meta_title()); ?>" />
<?php if(meta_description()): ?>
<meta name="description" content="<?php echo osc_esc_html(meta_description()); ?>" />
<?php endif; ?>
<?php if(function_exists('meta_keywords')): ?>
<?php if(meta_keywords()): ?>
<meta name="keywords" content="<?php echo osc_esc_html(meta_keywords()); ?>" />
<?php endif; ?>
<?php endif; ?>
<?php if(osc_get_canonical()): ?>
<link rel="canonical" href="<?php echo osc_get_canonical(); ?>"/>
<?php endif; ?>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache" />
<meta http-equiv="Expires" content="Mon, 01 Jul 1970 00:00:00 GMT" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
<?php if (file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/favicon.png")): ?>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo osc_current_web_theme_url('images/favicon.png');?>" />
<?php endif; ?>
<?php
osc_enqueue_style('jquery-ui', osc_current_web_theme_url('css/jquery-ui.css'));
osc_enqueue_style('bootstrap-select', osc_current_web_theme_url('css/bootstrap-select.min.css'));
osc_enqueue_style('lightbox', osc_current_web_theme_url('css/jquery.lightbox.min.css'));
osc_enqueue_style('fineuploader', osc_current_web_theme_js_url('fineuploader/fineuploader.css'));
osc_enqueue_style('style', osc_current_web_theme_url('css/style.css'), true);

osc_remove_style('font-open-sans');
osc_remove_style('open-sans');
osc_remove_style('fi_font-awesome');
osc_remove_style('font-awesome44');
osc_remove_style('font-awesome45');
osc_remove_style('responsiveslides');
osc_remove_style('cookiecuttr-style');

osc_register_script('jquery', osc_current_web_theme_js_url('jquery-1.11.1.min.js'));
osc_register_script('jquery-migrate', osc_current_web_theme_js_url('jquery-migrate-1.2.1.min.js'), 'jquery');
osc_register_script('bootstrap-js', osc_current_web_theme_js_url('bootstrap.min.js'), 'jquery');
osc_register_script('bootstrap-select-js', osc_current_web_theme_js_url('bootstrap-select.min.js'), 'jquery');
osc_register_script('jquery-ui-js', osc_current_web_theme_js_url('jquery-ui.min.js'), 'jquery');
osc_register_script('lightbox-js', osc_current_web_theme_js_url('jquery.lightbox.min.js'), 'jquery');
osc_register_script('parallax-js', osc_current_web_theme_js_url('parallax.min.js'), 'jquery');
osc_register_script('slick-js', osc_current_web_theme_js_url('slick.min.js'), 'jquery');
osc_register_script('touch', osc_current_web_theme_js_url('jquery.ui.touch-punch.min.js'), 'jquery');
osc_register_script('fineuploader-js', osc_current_web_theme_js_url('fineuploader/jquery.fineuploader.min.js'), 'jquery');
osc_register_script('validate-js', osc_current_web_theme_js_url('jquery.validate.min.js'), 'jquery');
osc_register_script('main-js', osc_current_web_theme_js_url('jquery.main.js'), 'jquery');
osc_register_script('date-js', osc_current_web_theme_js_url('date.js'), 'jquery');

osc_enqueue_script('jquery');
osc_enqueue_script('jquery-migrate');
osc_enqueue_script('bootstrap-js');
osc_enqueue_script('bootstrap-select-js');
osc_enqueue_script('jquery-ui-js');
osc_enqueue_script('touch');
osc_enqueue_script('lightbox-js');
osc_enqueue_script('parallax-js');
osc_enqueue_script('slick-js');
osc_enqueue_script('fineuploader-js');
osc_enqueue_script('validate-js');
osc_enqueue_script('date-js');
osc_enqueue_script('main-js');

osc_current_web_theme_path('inc.custom-styles.php');

osc_run_hook('header');
?>