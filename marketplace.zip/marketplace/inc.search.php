<?php 
    $category = __get("category");
    if(!isset($category['pk_i_id'])) $category['pk_i_id'] = null;
?>
<div class="s_box s_search">
	<form action="<?php echo osc_base_url(true); ?>" method="get" class="nocsrf">
        <input type="hidden" name="page" value="search"/>
        <input type="hidden" name="sOrder" value="<?php echo osc_search_order(); ?>" />
        <input type="hidden" name="iOrderType" value="<?php $allowedTypesForSorting = Search::getAllowedTypesForSorting(); echo $allowedTypesForSorting[osc_search_order_type()]; ?>" />
        
        <?php foreach(osc_search_user() as $userId): ?>
            <input type="hidden" name="sUser[]" value="<?php echo osc_esc_html($userId); ?>" />
        <?php endforeach; ?>
		<input type="hidden" name="sCompany" value="<?php echo Params::getParam('sCompany'); ?>">
		<input type="hidden" id="sRegion" name="sRegion" value="" />
        
		<div class="s_search-box s_search-box__mobile s_search-box__active">
			<div class="s_search-head s_search-head__name"><?php _e('Search', 'marketplace') ?></div>
			<div class="s_search-body">
				<div class="s_search-exactly">
					<input type="text" name="sPattern" value="<?php echo osc_esc_html(osc_search_pattern()); ?>" placeholder="<?php echo osc_esc_html(osc_get_preference('keyword_placeholder', 'marketplace_theme')); ?>">
				</div>
			</div>
		</div>

		<div class="s_search-box s_search-box__mobile s_search-box__active">
			<div class="s_search-head s_search-head__cat"><?php _e('Categories', 'marketplace') ?></div>
			<div class="s_search-body">
				<div class="c_select s_search-select">
					<select id="sCategory" name="sCategory" class="search-select" data-size="7">
	                    <?php marketplace_categories_select($category, 'Select category...'); ?> ?>
	                </select>
				</div>
			</div>
		</div>

		<div class="s_search-box">
			<div class="s_search-head s_search-head__location"><?php _e('Location', 'marketplace') ?></div>
			
            <div class="s_search-body">
                <?php if(osc_get_preference('search_country_field_status', 'marketplace_theme')): ?> 
                    <?php $countries = Country::newInstance()->listAll(); ?>
                    
                    <?php if(count($countries)): ?>
        				<div class="c_select s_search-select">
        					<select id="sCountry" class="search-select" data-size="7" name="sCountry">
                                <option value=""><?php echo osc_esc_html(__('Select a country...', 'marketplace'));?></option>
                                <?php foreach($countries as $country): ?>
                    				<option value="<?php echo $country['pk_c_code']; ?>" <?php if(Params::getParam('sCountry') !== '' && Params::getParam('sCountry') == $country['pk_c_code']) echo "selected"; ?>>
                                        <?php echo $country['s_name']; ?>
                                    </option>
                    			<?php endforeach; ?>
                            </select>
        				</div>
                    <?php endif; ?>
                <?php endif; ?>
                
				<div class="c_select s_search-select">
                    <?php if(osc_get_preference('search_country_field_status', 'marketplace_theme') && count($countries)): ?> 
    					<select id="sRegion" class="search-select" data-size="7" name="sRegion" <?php if(!Params::getParam('sCountry')): ?>disabled<?php endif; ?>>
                            <?php if(Params::getParam('sRegion') !== '' || Params::getParam('sCountry') !== ''): ?>
                                <?php $regions = Region::newInstance()->findByCountry(Params::getParam('sCountry')); ?>
                                <option value=""><?php _e('Select a region...', 'marketplace') ?></option>
                                
                                <?php foreach($regions as $region): ?>
                                    <option value="<?php echo $region['pk_i_id']; ?>" <?php if(Params::getParam('sRegion') !== '' && Params::getParam('sRegion') == $region['pk_i_id']) echo "selected"; ?>>
                                        <?php echo $region['s_name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <option value=""><?php _e('Select a country first...', 'marketplace') ?></option>
                            <?php endif; ?>
    	                </select>
                    <?php else: ?>
                        <?php $regions = Region::newInstance()->listAll(); ?>
                        <select id="sRegion" class="search-select" data-size="7" name="sRegion">
                            <option value=""><?php _e('Select a region...', 'marketplace') ?></option>
                            <?php if(count($regions)): ?>
                                <?php foreach($regions as $region): ?>
                                    <option value="<?php echo $region['pk_i_id']; ?>" <?php if(Params::getParam('sRegion') !== '' && Params::getParam('sRegion') == $region['pk_i_id']) echo "selected"; ?>>
                                        <?php echo $region['s_name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    <?php endif; ?>
				</div>
                
				<div class="c_select s_search-select">
					<select id="sCity" class="search-select" data-size="7" name="sCity" <?php if(!Params::getParam('sRegion')): ?>disabled<?php endif; ?>>
                        <?php if(Params::getParam('sRegion') !== '' || Params::getParam('sCity') !== ''): ?>
                            <?php $cities = City::newInstance()->findByRegion(Params::getParam('sRegion')); ?>
                            <option value=""><?php _e('Select city...', 'marketplace') ?></option>
                            
                            <?php foreach($cities as $city): ?>
                                <option value="<?php echo $city['pk_i_id']; ?>" <?php if(Params::getParam('sCity') !== '' && Params::getParam('sCity') == $city['pk_i_id']) echo "selected"; ?>>
                                    <?php echo $city['s_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value=""><?php _e('Select a region first...', 'marketplace') ?></option>
                        <?php endif; ?>
	                </select>
				</div>
			</div>
		</div>

		<div class="s_search-box">
			<div class="s_search-head s_search-head__price"><?php _e('Price', 'marketplace') ?></div>
			<div class="s_search-body s_search-range">
				<div id="slider-range" class="price-filter-range" name="rangeInput"></div>
				<input id="sPriceMin" class="price-range-field" type="number" name="sPriceMin" min="0" max="9900000" oninput="validity.valid||(value='0');" placeholder="<?php _e('Min', 'marketplace') ?>" value="<?php echo osc_esc_html(Params::getParam('sPriceMin')); ?>">
				<input id="sPriceMax" class="price-range-field" type="number" name="sPriceMax" min="0" max="10000000" oninput="validity.valid||(value='10000000');" placeholder="<?php _e('Max', 'marketplace') ?>" value="<?php echo osc_esc_html(Params::getParam('sPriceMax')); ?>">
			</div>
		</div>
		<?php if(osc_search_category_id()):?>
		<div class="s_search-body">
                              <?php osc_run_hook('search_form', osc_search_category_id()); ?>
							  </div>
                          <?php else: ?>
						  <div class="s_search-body">
                            <?php osc_run_hook('search_form'); ?>
							</div>
                            <?php endif; ?>
		<div class="s_search-body">
			<div class="s_search-show">
				<div class="s_search-show__head"><?php _e('Show only', 'marketplace') ?></div>
				<label for="withPicture">
					<input type="checkbox" name="bPic" id="withPicture" value="1" <?php echo (osc_search_has_pic() ? 'checked' : ''); ?>>
					<span class="s_search-show__label"><?php _e('listings with pictures', 'marketplace') ?></span>
				</label>
			</div>

			<div class="s_search-submit">
				<input type="submit" name="search" value="<?php _e('Search', 'marketplace') ?>">
			</div>
		</div>
	</form>
</div>

<script>
$(document).ready(function() {    
    $("body").on("change","#sCountry",function() {
        var pk_c_code = $(this).val();
        
        <?php if($path=="admin"): ?>
            var url = '<?php echo osc_admin_base_url(true) . "?page=ajax&action=regions&countryId="; ?>' + pk_c_code;
        <?php else: ?>
            var url = '<?php echo osc_base_url(true) . "?page=ajax&action=regions&countryId="; ?>' + pk_c_code;
        <?php endif; ?>
        
        var result = '';
        
        if(pk_c_code != '') {
            $.ajax({
                type: "GET",
                url: url,
                dataType: 'json',
                success: function(data){
                    var length = data.length;
                    
                    if(length > 0) {
                        result += '<option selected value=""><?php _e('Select a region...', 'marketplace'); ?></option>';
                        
                        for(key in data) {
                            result += '<option value="' + data[key].pk_i_id + '">' + data[key].s_name + '</option>';
                        }
                    } 
                    else {
                        result += '<option selected value=""><?php _e('No regions found', 'marketplace') ?></option>';
                    }
                    
                    $("select#sRegion").removeAttr('disabled').html(result).selectpicker('refresh');
                }
            });
        }
        else {
            $('select#sRegion').prop('disabled', true).remove('option').html('<option><?php _e('Select a country first...', 'marketplace'); ?></option>').selectpicker('refresh');
            $('select#sCity').prop('disabled', true).remove('option').html('<option><?php _e('Select a region first...', 'marketplace'); ?></option>').selectpicker('refresh');
        } 
    });
     
    $("body").on("change","select#sRegion",function(){
        var pk_c_code = $(this).val();
        
        <?php if($path=="admin"): ?>
            var url = '<?php echo osc_admin_base_url(true)."?page=ajax&action=cities&regionId="; ?>' + pk_c_code;
        <?php else: ?>
            var url = '<?php echo osc_base_url(true)."?page=ajax&action=cities&regionId="; ?>' + pk_c_code;
        <?php endif; ?>
        
        var result = '';
        
        if(pk_c_code != '') {
            $.ajax({
                type: "GET",
                url: url,
                dataType: 'json',
                success: function(data){
                    var length = data.length;
                    
                    if(length > 0) {
                        result += '<option selected value=""><?php _e('Select a city...', 'marketplace'); ?></option>';
                        
                        for(key in data) {
                            result += '<option value="' + data[key].pk_i_id + '">' + data[key].s_name + '</option>';
                        }
                    } 
                    else {
                        result += '<option selected value=""><?php _e('No cities found', 'marketplace') ?></option>';
                    }
                    
                    $("select#sCity").removeAttr('disabled').html(result).selectpicker('refresh');
                }
            });
        } 
        else {
            $('select#sCity').prop('disabled', true).remove('option').html('<option><?php _e('Select a region first...', 'marketplace'); ?></option>').selectpicker('refresh');
        }
    });
});
 </script>