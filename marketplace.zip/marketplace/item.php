<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        
        <main class="m_box c_main">
        	<div class="m_inb">
        		<div id="item-block" class="c_cont">
        			<div class="c_thumb tabs">
        
        				<ul class="tabs__caption c_thumb-caption">
                            <?php if(osc_images_enabled_at_items() && osc_count_item_resources()): ?>
        					   <li class="active"><?php _e('Images', 'marketplace') ?></li>
                            <?php endif; ?>
                            
                            <?php if(osc_get_preference('item_google_map', 'marketplace_theme')): ?>
        					   <li><?php _e('Map', 'marketplace') ?></li>
                            <?php endif; ?>
        				</ul>
                        
                        <?php if(osc_images_enabled_at_items() && osc_count_item_resources()): ?>
            				<div class="tabs__content c_single-box active">
            
            					<div class="c_thumb-big">
                                    <?php while(osc_has_item_resources()): ?>
                						<a href="<?php echo osc_resource_url() ; ?>" class="c_thumb-big__item" rel="lightbox">
                							<img src="<?php echo osc_resource_preview_url(); ?>" alt="<?php echo osc_esc_html(osc_item_title()); ?>">
                						</a>
                                    <?php endwhile; ?>
                                    <?php osc_reset_resources(); ?>
            					</div>
            
            					<div class="c_thumb-gallery">
                                    <?php while(osc_has_item_resources()): ?>
                						<div class="c_thumb-gallery__item">
                							<img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="single-min">
                						</div>
                                    <?php endwhile; ?>
            					</div>
            
            				</div>
                        <?php endif; ?>
                        
                        <?php if(osc_get_preference('item_google_map', 'marketplace_theme')): ?>
            				<div class="tabs__content c_single-box"   <?php if(!osc_images_enabled_at_items() or !osc_count_item_resources()): ?> style="display:block!important;"<?php endif; ?>>
							<?php if(osc_get_preference('map_api_key', 'marketplace_theme'))osc_current_web_theme_path('templates/map/item_map.php'); ?>
                             <?php osc_run_hook('location'); ?>								
            				</div>
        				<?php endif; ?>
        			</div>
                    
                    <?php if(osc_item_description() || osc_count_item_meta()): ?>
            			<div class="c_single-box c_single-desc">
            				<div class="c_single-head"><?php _e('Description', 'marketplace') ?></div>
            				<div class="c_txt">
            					 <?php echo osc_item_description(); ?>
                                 
                                 <?php if(osc_count_item_meta()): ?>
                                    <div class="meta_list">
                                        <?php while(osc_has_item_meta()): ?>
                                            <?php if(osc_item_meta_value()): ?>
                                                <div class="meta">
                                                    <strong><?php echo osc_item_meta_name(); ?>:</strong> <?php echo osc_item_meta_value(); ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php endwhile; ?>
                                    </div>
                                 <?php endif; ?>
                                 
                                 <?php osc_run_hook('item_detail', osc_item()); ?>
            				</div>
            			</div>
                    <?php endif; ?>
                    
                    <?php if(osc_get_preference('ads_ip_un_desc', 'marketplace_theme')): ?>
                        <div class="ads-block">
                            <?php echo osc_get_preference('ads_ip_un_desc', 'marketplace_theme'); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if(osc_comments_enabled()): ?>
                        <?php osc_current_web_theme_path('item-send-friend.php'); ?>
                    <?php endif; ?>
        		</div>
        
        		<aside class="c_side">
        
        			<div class="s_box s_info">
        				<div class="s_box-dark">
        					<div class="s_info-name"><?php echo osc_esc_html(osc_item_title()); ?></div>
                            <a href="<?php echo marketplace_category_url(marketplace_category_root(osc_item_category_id())); ?>" class="s_info-cat c_item-cat__classes <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_item_category_id()) . ".png")): ?>
                                    <img border="0" style="position: relative;top: -2px;max-width: 35px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_item_category_id()) . '.png');?>" />
                                <?php endif; ?>
                                <?php echo marketplace_category_root_name(osc_item_category_id()); ?>
                            </a>
        				</div>
                        <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled()): ?>
                            <div class="s_info-item c_item-price"><?php echo osc_item_formated_price(); ?></div>
                        <?php endif; ?>
                        
                        <?php if(osc_item_pub_date()): ?>
                            <div class="s_info-item s_info-item__date"><?php echo osc_format_date(osc_item_pub_date()); ?></div>
                        <?php endif; ?>
        				<div class="s_info-item s_info-item__views"><?php echo osc_item_views(); ?></div>
						                               <?php if( osc_get_preference('item_mark', 'marketplace_theme')): ?>
													   <div class="s_user-button">      
            						<div class="c_select s_user-button__item">
                                        <form action="<?php echo osc_base_url(true); ?>" method="post" name="mask_as_form" id="mask_as_form">
                                            <input type="hidden" name="id" value="<?php echo osc_item_id(); ?>" />
                                            <input type="hidden" name="as" value="spam" />
                                            <input type="hidden" name="action" value="mark" />
                                            <input type="hidden" name="page" value="item" />
                                            
                							<select id="mark-as" class="selectpicker" data-size="7">
                                                <option value=""> <?php _e("Mark as...", 'marketplace'); ?></option>
                                                <option value="spam"><?php _e("Mark as spam", 'marketplace'); ?></option>
                                                <option value="badcat"><?php _e("Mark as misclassified", 'marketplace'); ?></option>
                                                <option value="repeated"><?php _e("Mark as duplicated", 'marketplace'); ?></option>
                                                <option value="expired"><?php _e("Mark as expired", 'marketplace'); ?></option>
                                                <option value="offensive"><?php _e("Mark as offensive", 'marketplace'); ?></option>
                			                </select>
                                        </form>
            						</div></div>
                                <?php endif; ?>
        			</div>
                    
                    <?php if(osc_get_preference('ads_ip_sidebar', 'marketplace_theme')): ?>
                        <div class="s_box s_info">
                            <div class="ads-block">
                                <?php echo osc_get_preference('ads_ip_sidebar', 'marketplace_theme'); ?>
                            </div>
                        </div>
                    <?php endif; ?>
        
        			<div class="side_fix">
        
        				<div class="s_box s_user">
        					<div class="s_box-dark s_user-whois">
        						<div class="s_user-thumb"></div>
        						<div class="s_user-ident">
        							<div class="s_user-ident__name">
                                        <?php echo osc_item_contact_name(); ?>
                                    </div>
                                    
        							<div class="s_user-ident__posit">
                                        <?php if(osc_user_is_company()) _e('Company', 'marketplace'); else _e('User', 'marketplace'); ?>
                                    </div>
        						</div>
        					</div>
                            
                            <?php if(osc_user_phone_land()): ?>
        					   <a href="javascript: void(0);" class="s_info-item s_info-item__phone"><?php marketplace_phone_number(); ?></a>
                            <?php endif; ?>
                            
                            <?php if(osc_user_phone_mobile()): ?>
        					   <a href="javascript: void(0);" class="s_info-item s_info-item__phone"><?php marketplace_mobile_number(); ?></a>
                            <?php endif; ?>
                            
                            <?php
                              $location_array = array(osc_item_country(), osc_item_region(), osc_item_city(), osc_item_city_area(), osc_item_address());
                              $location_array = array_filter($location_array);
                              $item_loc = implode(', ', $location_array);
                            ?>
                            
                            <?php if($item_loc): ?>
        					   <div class="s_info-item s_info-item__adres"><?php echo $item_loc; ?></div>
                            <?php endif; ?>
							<?php if(osc_item_user_id() != null): ?> 
        					<div class="s_user-button">                           
<a href="<?php echo osc_user_public_profile_url(osc_item_user_id()); ?>" class="s_user-button__item"><?php _e('Profile', 'marketplace') ?></a>
        					</div>
 <?php endif; ?>							
        				</div>
                        
                        <?php osc_current_web_theme_path('item-contact.php'); ?>
        			</div>
        
        		</aside>
        	</div>
        </main><!-- .main -->
        
        
        <main class="m_box c_main c_related">
        	<div class="m_inb">
        		<div class="c_cont">
                    <?php if (function_exists('marketplace_related_listings')) marketplace_related_listings(); ?>
                    <?php if(osc_count_items()): ?>
                        <div class="c_related-head"><?php _e('Related Ads', 'marketplace') ?></div>
            			
                        <div class="c_list">
                            <?php while(osc_has_items()): ?>
                                <div class="c_item">
                					<div class="c_item-thumb">
                                        <?php if(osc_images_enabled_at_items() && osc_count_item_resources()): ?>
                    					   <div class="c_item-photo"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_highlight(osc_item_title()); ?>"></div>
                                        <?php else: ?>
                                            <div class="c_item-photo"><img style="min-height: auto;" src="<?php echo osc_current_web_theme_url('images/no_photo.gif') ; ?>" alt="<?php _e('No Photo', 'marketplace') ?>"></div>
                                        <?php endif; ?>
                                        
                                        <?php if(osc_item_is_premium()): ?>
                                            <div class="c_item-favorite"></div>
                                        <?php endif; ?>
                					</div>
                					<div class="c_item-info">
                                        <div class="c_item-ins">
                    						<a href="<?php echo osc_item_url() ; ?>" class="c_item-title">
                                                <?php if(strlen(osc_item_title()) > 25) echo mb_substr(osc_highlight(osc_item_title()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_title()); ?>
                                            </a>
                                            
                    						<div class="c_item-desc">
                                                <?php if(strlen(osc_item_description()) > 25) echo mb_substr(osc_highlight(osc_item_description()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_description()); ?>
                                            </div>
                                            
                    						<a href="<?php echo marketplace_category_url(marketplace_category_root(osc_item_category_id())); ?>" class="c_item-cat <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                                <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_item_category_id()) . ".png")): ?>
                                                    <img border="0" style="position: relative;top: -5px;max-width: 40px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_item_category_id()) . '.png');?>" />
                                                <?php endif; ?>
                                                <?php echo marketplace_category_root_name(osc_item_category_id()); ?>
                                            </a>
                                            <div class="c_item-photos"><?php echo osc_count_item_resources(); ?></div>
                    						<a href="<?php echo osc_item_url() ; ?>" class="c_item-view"><?php _e('View item', 'marketplace') ?></a>
                                        </div>
                					</div>
                					<div class="c_item-addit">
                                        <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_item_category_id())): ?>
                                            <div class="c_item-price"><?php echo osc_item_formated_price(); ?></div>
                                        <?php endif; ?>
                                        
                						<a href="<?php echo osc_item_url() ; ?>" class="c_item-more"><?php _e('Learn more', 'marketplace') ?></a>
                                        <div class="c_item-location"><?php echo osc_item_city(); ?></div>
                					</div>
                				</div>
                            <?php endwhile; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if(osc_get_preference('item_useful_info_status', 'marketplace_theme')): ?>
            			<div class="c_single-box c_useful">
            				<div class="c_single-head"><?php _e('Useful information', 'marketplace') ?></div>
            				<div class="c_txt">
            					<p><?php echo osc_get_preference('item_useful_info_text', 'marketplace_theme'); ?></p>
            				</div>
            			</div><!-- /c_useful -->
                    <?php endif; ?>
                    
                    <?php if(osc_get_preference('ads_ip_un_info', 'marketplace_theme')): ?>
                        <div class="ads-block">
                            <?php echo osc_get_preference('ads_ip_un_info', 'marketplace_theme'); ?>
                        </div>
                    <?php endif; ?>
        		</div>
                
        		<aside class="c_side">
        			<?php osc_current_web_theme_path('inc.search.php'); ?>
        		</aside>
        	</div>
        </main><!-- .main -->
        
        <script type="text/javascript">
            $('#mark-as').change(function() {
                if($(this).val()) {
                    if(confirm('<?php echo osc_esc_js(__('This action can not be undone. Are you sure you want to continue?', 'marketplace')); ?>')) {
                        $('#mask_as_form').submit();
                    }   
                    
                    $('#mark-as').selectpicker('val', '');
                }
            });
        </script>
        
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>