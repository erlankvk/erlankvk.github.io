<?php defined('ABS_PATH') or die('Access denied'); 
    $categories = Category::newInstance()->toTreeAll();
?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <?php require_once 'left-menu.php'; ?>
    <div class="ua-manage-content ua-section">
        <div style="margin:15px;">
            <?php if($categories): ?>
                <div class="alert alert-info">
                    <p><?php _e('The recomended size of the icon is ~', 'marketplace'); ?> 50х50.</p>
                    <p><?php _e('<strong>Note:</strong> Uploading another icon will overwrite the current icon.', 'marketplace'); ?></p>
                    <p><?php _e('Following format is allowed: png','marketplace'); ?></p>
                </div>
                
                <table class="table-striped">
                    <?php foreach($categories as $category): ?>
                        <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=main'); ?>" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="action_specific" value="marketplace_category_icons" />
                            <input type="hidden" name="category_id" value="<?php echo $category['pk_i_id']; ?>" />
                            
                            <tr>
                                <td><strong><?php echo $category['s_name']; ?></strong></td>
                                <td>
                                    <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . $category['pk_i_id'] . ".png")): ?>
                                        <img border="0" style="max-width: 50px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . $category['pk_i_id'] . '.png');?>" />
                                    <?php else: ?>
                                        <?php _e('No icon', 'marketplace'); ?>
                                    <?php endif; ?>
                                </td>
                                <td><input type="file" name="category_icon" id="package" accept="image/x-png"/></td>
                                <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload','marketplace')); ?></button></td>
                            </tr>
                            
                        </form>
                    <?php endforeach; ?>
                </table>
            <?php else: ?>
                <div class="alert alert-warning"><?php _e('No categories', 'marketplace'); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>