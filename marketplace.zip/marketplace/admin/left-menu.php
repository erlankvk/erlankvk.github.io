<?php defined('ABS_PATH') or die('Access denied'); ?>
<div class="ua-manage-menu">
    <ul>
        <li <?php if(marketplace_left_menu('basic')): ?>class="active"<?php endif; ?>>
            <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=basic'); ?>">
                <?php _e('Basic Settings', 'marketplace'); ?>
            </a>
        </li>
        
        <li <?php if(marketplace_left_menu('main')): ?>class="active"<?php endif; ?>>
            <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/main.php&m=settings&l=main'); ?>">
                <?php _e('Main', 'marketplace'); ?>
            </a>
        </li>
        
        <li <?php if(marketplace_left_menu('footer')): ?>class="active"<?php endif; ?>>
            <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/footer.php&m=settings&l=footer'); ?>">
                <?php _e('Footer', 'marketplace'); ?>
            </a>
        </li>
        
        <li <?php if(marketplace_left_menu('category')): ?>class="active"<?php endif; ?>>
            <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/category-icons.php&m=settings&l=category'); ?>">
                <?php _e('Category Icons', 'marketplace'); ?>
            </a>
        </li>
        
        <li <?php if(marketplace_left_menu('favicon')): ?>class="active"<?php endif; ?>>
            <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/favicon.php&m=settings&l=favicon'); ?>">
                <?php _e('Favicon', 'marketplace'); ?>
            </a>
        </li>
        
        <li <?php if(marketplace_left_menu('search')): ?>class="active"<?php endif; ?>>
            <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/search.php&m=settings&l=search'); ?>">
                <?php _e('Search Page', 'marketplace'); ?>
            </a>
        </li>
        
        <li <?php if(marketplace_left_menu('colors')): ?>class="active"<?php endif; ?>>
            <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/colors.php&m=settings&l=colors'); ?>">
                <?php _e('Colors', 'marketplace'); ?>
            </a>
        </li>
        
        <li <?php if(marketplace_left_menu('items')): ?>class="active"<?php endif; ?>>
            <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/items.php&m=settings&l=items'); ?>">
                <?php _e('Items', 'marketplace'); ?>
            </a>
        </li>
        
        <li <?php if(marketplace_left_menu('related')): ?>class="active"<?php endif; ?>>
            <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/related-items.php&m=settings&l=related'); ?>">
                <?php _e('Related Items', 'marketplace'); ?>
            </a>
        </li>
    </ul>
</div>