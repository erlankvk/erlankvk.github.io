<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <?php require_once 'left-menu.php'; ?>
    <div class="ua-manage-content ua-section">
        <div style="margin:15px;">
            <div class="cd-tabs">
                <nav>
                    <ul class="cd-tabs-navigation">
                        <li><a data-content="top" class="selected" href="javascript:void(0);"><?php _e('Top Background', 'marketplace'); ?></a></li>
                        <li><a data-content="middle" href="javascript:void(0);"><?php _e('Middle Background', 'marketplace'); ?></a></li>
                        <li><a data-content="bottom" href="javascript:void(0);"><?php _e('Bottom Background', 'marketplace'); ?></a></li>
                    </ul>
                </nav>
                
                <ul class="cd-tabs-content">
                    <li data-content="top" class="selected">
                        <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=main'); ?>" method="post">
                            <input type="hidden" name="action_specific" value="marketplace_main_top_text" />
                            
                            <table class="table-striped table-2-cols">
                                <tr>
                                    <td><?php _e('H1 Intro Text', 'marketplace') ?>:</td>
                                    <td><input type="text" name="h1_intro_text" value="<?php echo osc_esc_html(osc_get_preference('h1_intro_text', 'marketplace_theme')); ?>" /></td>
                                </tr>
                                
                                <tr>
                                    <td><?php _e('H2 Intro Text', 'marketplace') ?>:</td>
                                    <td><input type="text" name="h2_intro_text" value="<?php echo osc_esc_html(osc_get_preference('h2_intro_text', 'marketplace_theme')); ?>" /></td>
                                </tr>
                            </table> 
                
                            <div class="form-actions">
                                <input type="submit" id="save_changes" value="<?php echo osc_esc_html(__("Save changes", 'marketplace')); ?>" class="btn btn-submit">
                            </div>        
                        </form>
                        
                        <h3><?php _e('Upload Background', 'marketplace') ?></h3>
                        <div class="alert alert-info">
                            <p>
                                <?php _e('The recomended size of the background is ~', 'marketplace'); ?> 1920x600.
                            </p>
                            
                            <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/bg-head.jpg")): ?>
                                <p><?php _e('<strong>Note:</strong> Uploading another background will overwrite the current background.', 'marketplace'); ?></p>
                            <?php endif; ?>
                            
                            <p><?php _e('Following formats are allowed: png, gif, jpg','marketplace'); ?></p>
                        </div>
                        <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=main'); ?>" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="action_specific" value="marketplace_upload_main_top_bg" />
                            
                            <table class="table table-no-border">
                                <tr>
                                    <td><img border="0" style="max-width: 600px;" alt="<?php echo osc_esc_html(osc_page_title()); ?>" src="<?php echo osc_current_web_theme_url('images/bg-head.jpg');?>" /></td>
                                </tr>
                    
                                <tr>
                                    <td style="width: 180px;"><input id="main-top-bg" type="file" name="main_top_bg" accept="image/*" /></td>
                                </tr>
                                
                                <tr>
                                    <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload Background','marketplace')); ?></button></td>
                                </tr>
                            </table>
                        </form>
                    </li>
                    
                    <li data-content="middle">
                        <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=main'); ?>" method="post">
                            <input type="hidden" name="action_specific" value="marketplace_main_middle_text" />
                            
                            <table class="table-striped table-2-cols">
                                <tr>
                                    <td><?php _e('Middle Block', 'marketplace') ?>:</td>
                                    <td>
                                        <div data-toggle="switch">
                                            <input class="checkbox" type="checkbox" name="middle_block_status" value="1" <?php echo (osc_get_preference('middle_block_status', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                                        </div>
                                    </td>
                                </tr>
                    
                                <tr>
                                    <td><?php _e('H2 First Text', 'marketplace') ?>:</td>
                                    <td><input type="text" name="first_md_text" value="<?php echo osc_esc_html(osc_get_preference('first_md_text', 'marketplace_theme')); ?>" /></td>
                                </tr>
                                
                                <tr>
                                    <td><?php _e('Description to the first text', 'marketplace') ?>:</td>
                                    <td><textarea name="first_md_description" rows="8"><?php echo osc_esc_html(osc_get_preference('first_md_description', 'marketplace_theme')); ?></textarea></td>
                                </tr>
                                
                                <tr>
                                    <td><?php _e('Text of the first list item', 'marketplace') ?>:</td>
                                    <td><input type="text" name="first_md_list" value="<?php echo osc_esc_html(osc_get_preference('first_md_list', 'marketplace_theme')); ?>" /></td>
                                </tr>
                                
                                <tr>
                                    <td><?php _e('Text of the second list item', 'marketplace') ?>:</td>
                                    <td><input type="text" name="second_md_list" value="<?php echo osc_esc_html(osc_get_preference('second_md_list', 'marketplace_theme')); ?>" /></td>
                                </tr>
                                
                                <tr>
                                    <td><?php _e('The text of the last item in the list', 'marketplace') ?>:</td>
                                    <td><input type="text" name="last_md_list" value="<?php echo osc_esc_html(osc_get_preference('last_md_list', 'marketplace_theme')); ?>" /></td>
                                </tr>
                                
                                <tr>
                                    <td><?php _e('H2 Last Text', 'marketplace') ?>:</td>
                                    <td><input type="text" name="last_md_text" value="<?php echo osc_esc_html(osc_get_preference('last_md_text', 'marketplace_theme')); ?>" /></td>
                                </tr>
                            </table> 
                
                            <div class="form-actions">
                                <input type="submit" id="save_changes" value="<?php echo osc_esc_html(__("Save changes", 'marketplace')); ?>" class="btn btn-submit">
                            </div>        
                        </form>
                        
                        <h3><?php _e('Upload Background', 'marketplace') ?></h3>
                        <div class="alert alert-info">
                            <p>
                                <?php _e('The recomended size of the background is ~', 'marketplace'); ?> 1920x720.
                            </p>
                            
                            <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/bg-whychoose.jpg")): ?>
                                <p><?php _e('<strong>Note:</strong> Uploading another background will overwrite the current background.', 'marketplace'); ?></p>
                            <?php endif; ?>
                            
                            <p><?php _e('Following formats are allowed: png, gif, jpg','marketplace'); ?></p>
                        </div>
                        <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=main'); ?>" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="action_specific" value="marketplace_upload_main_middle_bg" />
                            
                            <table class="table table-no-border">
                                <tr>
                                    <td><img border="0" style="max-width: 600px;" alt="<?php echo osc_esc_html(osc_page_title()); ?>" src="<?php echo osc_current_web_theme_url('images/bg-whychoose.jpg');?>" /></td>
                                </tr>
                    
                                <tr>
                                    <td style="width: 180px;"><input id="main-middle-bg" type="file" name="main_middle_bg" accept="image/*" /></td>
                                </tr>
                                
                                <tr>
                                    <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload Background','marketplace')); ?></button></td>
                                </tr>
                            </table>
                        </form>
                    </li>
                    
                    <li data-content="bottom">
                        <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=main'); ?>" method="post">
                            <input type="hidden" name="action_specific" value="marketplace_main_bottom_text" />
                            
                            <table class="table-striped table-2-cols">
                                <tr>
                                    <td><?php _e('Bottom Block', 'marketplace') ?>:</td>
                                    <td>
                                        <div data-toggle="switch">
                                            <input class="checkbox" type="checkbox" name="bottom_block_status" value="1" <?php echo (osc_get_preference('bottom_block_status', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                                        </div>
                                    </td>
                                </tr>
                    
                                <tr>
                                    <td><?php _e('H2 Left Text', 'marketplace') ?>:</td>
                                    <td><input type="text" name="h2_left_bm_text" value="<?php echo osc_esc_html(osc_get_preference('h2_left_bm_text', 'marketplace_theme')); ?>" /></td>
                                </tr>
                                
                                <tr>
                                    <td><?php _e('Left subtitle text', 'marketplace') ?>:</td>
                                    <td><input type="text" name="subtitle_left_bm_text" value="<?php echo osc_esc_html(osc_get_preference('subtitle_left_bm_text', 'marketplace_theme')); ?>" /></td>
                                </tr>
                                
                                <tr>
                                    <td><?php _e('H2 Right Text', 'marketplace') ?>:</td>
                                    <td><input type="text" name="h2_right_bm_text" value="<?php echo osc_esc_html(osc_get_preference('h2_right_bm_text', 'marketplace_theme')); ?>" /></td>
                                </tr>
                                
                                <tr>
                                    <td><?php _e('Right subtitle text', 'marketplace') ?>:</td>
                                    <td><input type="text" name="subtitle_right_bm_text" value="<?php echo osc_esc_html(osc_get_preference('subtitle_right_bm_text', 'marketplace_theme')); ?>" /></td>
                                </tr>
                            </table> 
                
                            <div class="form-actions">
                                <input type="submit" id="save_changes" value="<?php echo osc_esc_html(__("Save changes", 'marketplace')); ?>" class="btn btn-submit">
                            </div>        
                        </form>
                        
                        <h3><?php _e('Upload Background', 'marketplace') ?></h3>
                        <div class="alert alert-info">
                            <p>
                                <?php _e('The recomended size of the background is ~', 'marketplace'); ?> 1920x450.
                            </p>
                            
                            <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/bg-wwdev.jpg")): ?>
                                <p><?php _e('<strong>Note:</strong> Uploading another background will overwrite the current background.', 'marketplace'); ?></p>
                            <?php endif; ?>
                            
                            <p><?php _e('Following formats are allowed: png, gif, jpg','marketplace'); ?></p>
                        </div>
                        <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=main'); ?>" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="action_specific" value="marketplace_upload_main_bottom_bg" />
                            
                            <table class="table table-no-border">
                                <tr>
                                    <td><img border="0" style="max-width: 600px;" alt="<?php echo osc_esc_html(osc_page_title()); ?>" src="<?php echo osc_current_web_theme_url('images/bg-wwdev.jpg');?>" /></td>
                                </tr>
                    
                                <tr>
                                    <td style="width: 180px;"><input id="main-bottom-bg" type="file" name="main_bottom_bg" accept="image/*" /></td>
                                </tr>
                                
                                <tr>
                                    <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload Background','marketplace')); ?></button></td>
                                </tr>
                            </table>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>