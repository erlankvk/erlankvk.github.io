<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <div style="margin:15px;">
        <div class="accordion">
		<section class="accordion_item">
                <h3 class="title_block"><?php _e('Control of the size of images', 'marketplace'); ?></h3>
                
                <div class="info">
                    <p class="info_item">
                        <?php _e('The panel of the administrator - Settings - Media:', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('The miniature size - 253x191', 'marketplace'); ?>.
                    </p>
					<p class="info_item">
                        <?php _e('The preview size - 740x494', 'marketplace'); ?>.
                    </p>
					<p class="info_item">
                        <?php _e('The normal size - 958x640( For normal size you can setup bigger size. This is image used in item page in Popup window)', 'marketplace'); ?>.
                    </p>
					<p class="info_item">
                        <?php _e('Disable - Force image aspect. No white background will be added to keep the size.', 'marketplace'); ?>.
                    </p>
					<p class="info_item">
                        <?php _e('Enable - Use ImageMagick instead of GD library', 'marketplace'); ?>.
                    </p>
                </div>
            </section>
            <section class="accordion_item">
                <h3 class="title_block"><?php _e('Advertising', 'marketplace'); ?></h3>
                
                <div class="info">
                    <p class="info_item">
                        <?php _e('Manage advertising platform, such as Google Adsense', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('Homepage and search middle of latest listings work only for list view', 'marketplace'); ?>.
                    </p>
                </div>
            </section>
            
            <section class="accordion_item">
                <h3 class="title_block"><?php _e('Icons for categories', 'marketplace'); ?></h3>
                
                <div class="info">
                    <p class="info_item">
                        <?php _e('If you change standart Osclass categories (or add new), it is necessary for you to make the icons for the changed categories', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('The size of images should be ~ 50x50px', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('Images, for example, can be taken here:', 'marketplace'); ?>
                    </p>
                    
                    <p class="info_item">
                        <a href="http://www.flaticon.com/free-icon/black-car_16301" target="_blank">http://www.flaticon.com/free-icon/black-car_16301</a>
                    </p>
                    
                    <p class="info_item">
                        <?php _e('Go to Category icons and upload icons', 'marketplace'); ?>.
                    </p>
                </div>
            </section>
            
            <section class="accordion_item">
                <h3 class="title_block"><?php _e('Search Max-Min price edit', 'marketplace'); ?></h3>
                
                <div class="info">
                    <p class="info_item">
                        <?php _e('Open marketplace/js/main.js in 137 line min = 0; min price to select', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('In 138 line max = 1000000; max price', 'marketplace'); ?>.
                    </p>
                </div>
            </section>
            
            <section class="accordion_item">
                <h3 class="title_block"><?php _e('Google Map in Main and Search pages', 'marketplace'); ?></h3>
                
                <div class="info">
                    <p class="info_item">
                        <?php _e('All ads on the map are added by the coordinates', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('If your site already had ads, but the Google map plugin was not installed before:each time the map is loaded, the coordinates will be calculated', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('The map can be loaded long if you configure a lot of ads to display on the map', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('But if you turn on the theme Map or install the Google map plugin:when user adding new ads to the site, the coordinates will be immediately calculated and saved to the database for each new ad', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('The map will be loaded much faster, so the coordinates will be taken from the database', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('If the user specified an incorrect address, the ad will not be shown on the map', 'marketplace'); ?>.
                    </p>
                </div>
            </section>
            
            <section class="accordion_item">
                <h3 class="title_block"><?php _e('Google Map keys', 'marketplace'); ?></h3>
                
                <div class="info">
				<p class="info_item"><?php _e('Google Maps require use APi keys', 'marketplace'); ?></p>
	<p class="info_item"><?php _e('Google give $200 each month for using API. If you spend these $ 200, Google will charge you for using api.', 'marketplace'); ?></p>
	<p class="info_item"><?php _e('This may change in the future. Google itself sets the rules. More about pricing and free limits', 'marketplace'); ?>:</p>
	<p class="info_item"><a href="https://cloud.google.com/maps-platform/pricing/sheet/" class="underlink" target="_blank">https://cloud.google.com/maps-platform/pricing/sheet/</a></p>
                    <p class="info_item">
                        <?php _e('Unfortunately Google not allow limit access to Google Map Api for domain and IP together', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('In this one, you can either restrict access by domain, or by IP', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('Google Maps JavaScript Api work with URLS and in can be restricted by domain name', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('But Google Geocoding Api Key send request to API from server IP and in can be restricted by IP only', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('That is why we recommend creating two keys. First key for Google Maps JavaScript Api and restrict it by your domain name', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item"><img border="0" src="<?php echo osc_current_web_theme_url('admin/images/help-1.jpg');?>" /></p>
                    
                    <p class="info_item">
                        <?php _e('Second key for Google Geocoding Api and restrict it by your server IP', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item"><img border="0" src="<?php echo osc_current_web_theme_url('admin/images/help-2.jpg');?>" /></p>
                </div>
            </section>
            
            <section class="accordion_item">
                <h3 class="title_block"><?php _e('Translation', 'marketplace'); ?></h3>
                
                <div class="info">
                    <p class="info_item">
                        <?php _e('You can translate or edit theme translations with Poedit', 'marketplace'); ?>.
                    </p>
                    
                    <p class="info_item">
                        <?php _e('Osclass DOCS', 'marketplace'); ?>: 
						<?php if( osc_current_admin_locale () == 'ru_RU') { ?>
	 <a href="https://osclass.pro/perevod-shablonov-i-plaginov/" class="underlink" target="_blank">https://osclass.pro/perevod-shablonov-i-plaginov/</a>
	 <?php } else { ?>
                        <a href="https://osclass-pro.com/en/translate_theme_or_plugin.html" target="_blank">https://osclass-pro.com/en/translate_theme_or_plugin.html</a>
                   <?php } ?>
				   </p>
                </div>
            </section>
        </div>
    </div>
</div>

<script type="text/javascript">
! function(i) {
  var o, n;
  i(".title_block").on("click", function() {
    o = i(this).parents(".accordion_item"), n = o.find(".info"),
      o.hasClass("active_block") ? (o.removeClass("active_block"),
        n.slideUp()) : (o.addClass("active_block"), n.stop(!0, !0).slideDown(),
        o.siblings(".active_block").removeClass("active_block").children(
          ".info").stop(!0, !0).slideUp())
  })
}(jQuery);
</script>