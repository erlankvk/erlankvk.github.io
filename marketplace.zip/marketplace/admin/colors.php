<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <?php require_once 'left-menu.php'; ?>
    <div class="ua-manage-content ua-section">
        <div style="margin:15px;">
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=color'); ?>" method="post">
                <input type="hidden" name="action_specific" value="marketplace_color_settings" />
                
                <table class="table-striped table-2-cols">
                    <tr>
                        <td><?php _e('Publish Ad button color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_publish_item" value="<?php echo osc_esc_html(osc_get_preference('color_publish_item', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Publish Ad button hover color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_publish_item_hover" value="<?php echo osc_esc_html(osc_get_preference('color_publish_item_hover', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('The other buttons color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_other_btns" value="<?php echo osc_esc_html(osc_get_preference('color_other_btns', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('The other buttons hover color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_other_btns_hover" value="<?php echo osc_esc_html(osc_get_preference('color_other_btns_hover', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Forms Header Background color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_forms_bg_header" value="<?php echo osc_esc_html(osc_get_preference('color_forms_bg_header', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Forms Header Font color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_forms_font_header" value="<?php echo osc_esc_html(osc_get_preference('color_forms_font_header', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Side Blocks Header Background color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_side_block_bg_header" value="<?php echo osc_esc_html(osc_get_preference('color_side_block_bg_header', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Side Blocks Header Font color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_side_block_font_header" value="<?php echo osc_esc_html(osc_get_preference('color_side_block_font_header', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Сategory label background color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_category_label_bg" value="<?php echo osc_esc_html(osc_get_preference('color_category_label_bg', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Сategory label font color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_category_label_font" value="<?php echo osc_esc_html(osc_get_preference('color_category_label_font', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Сategory label background hover color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_category_label_bg_hover" value="<?php echo osc_esc_html(osc_get_preference('color_category_label_bg_hover', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Сategory label font hover color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_category_label_font_hover" value="<?php echo osc_esc_html(osc_get_preference('color_category_label_font_hover', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Premium Item label background color', 'marketplace') ?>:</td>
                        <td><input type="color" name="color_prem_item_label_bg" value="<?php echo osc_esc_html(osc_get_preference('color_prem_item_label_bg', 'marketplace_theme')); ?>" /></td>
                    </tr>
                </table> 
                
                <div class="form-actions">
                    <input type="submit" id="save_changes" value="<?php echo osc_esc_html(__("Save changes", 'marketplace')); ?>" class="btn btn-submit">
                </div>        
            </form>
        </div>
    </div>
</div>