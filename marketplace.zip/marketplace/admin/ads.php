<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <div style="margin:15px;">
        <div class="alert alert-info">
            <p><?php _e('In this section you can configure your site to display ads and start generating revenue.', 'marketplace'); ?></p>
            <p><?php _e('If you are using an online advertising platform, such as Google Adsense, copy and paste here the provided code for ads.', 'marketplace'); ?></p>
            <p><?php _e('Important! Google Adsense allows you to place only three blocks in page','marketplace'); ?></p>
        </div>
        
        <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/ads.php'); ?>" method="post">
            <input type="hidden" name="action_specific" value="marketplace_ads" />
            
            <table class="table-striped table-2-cols">
                <tr>
                    <td>
                        <?php _e('Main page under categories', 'marketplace') ?>:
                        <i id="tips" data-tipso='<?php _e('This ad will be shown at the Main page under categories. Note that the ad should be Responsive.', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                    </td>
                    <td><textarea name="ads_hp_un_categories" rows="8"><?php echo osc_esc_html(osc_get_preference('ads_hp_un_categories', 'marketplace_theme')); ?></textarea></td>
                </tr>
                
                <tr>
                    <td>
                        <?php _e('Homepage top of latest listings', 'marketplace') ?>:
                        <i id="tips" data-tipso='<?php _e('This ad will be shown at the top of your latest listings in main page. Note that the ad should be Responsive.', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                    </td>
                    <td><textarea name="ads_hp_top_latest_items" rows="8"><?php echo osc_esc_html(osc_get_preference('ads_hp_top_latest_items', 'marketplace_theme')); ?></textarea></td>
                </tr>
                
                <tr>
                    <td>
                        <?php _e('Homepage under of latest listings', 'marketplace') ?>:
                        <i id="tips" data-tipso='<?php _e('This ad will be shown on the main page under of your latest listings. Note that the ad should be Responsive.', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                    </td>
                    <td><textarea name="ads_hp_un_latest_items" rows="8"><?php echo osc_esc_html(osc_get_preference('ads_hp_un_latest_items', 'marketplace_theme')); ?></textarea></td>
                </tr>
                
                <tr>
                    <td>
                        <?php _e('Search results top', 'marketplace') ?>:
                        <i id="tips" data-tipso='<?php _e('This ad will be shown at the top search results of your site. Note that the ad should be Responsive.', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                    </td>
                    <td><textarea name="ads_sp_top" rows="8"><?php echo osc_esc_html(osc_get_preference('ads_sp_top', 'marketplace_theme')); ?></textarea></td>
                </tr>
                
                <tr>
                    <td>
                        <?php _e('Search under of listings', 'marketplace') ?>:
                        <i id="tips" data-tipso='<?php _e('This ad will be shown on the search page under of your listings. Note that the ad should be Responsive.', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                    </td>
                    <td><textarea name="ads_sp_un" rows="8"><?php echo osc_esc_html(osc_get_preference('ads_sp_un', 'marketplace_theme')); ?></textarea></td>
                </tr>
                
                <tr>
                    <td>
                        <?php _e('Item under of listing description', 'marketplace') ?>:
                        <i id="tips" data-tipso='<?php _e('This ad will be shown on the item page under of listing description. Note that the ad should be Responsive.', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                    </td>
                    <td><textarea name="ads_ip_un_desc" rows="8"><?php echo osc_esc_html(osc_get_preference('ads_ip_un_desc', 'marketplace_theme')); ?></textarea></td>
                </tr>
                
                <tr>
                    <td>
                        <?php _e('Item under useful info', 'marketplace') ?>:
                        <i id="tips" data-tipso='<?php _e('This ad will be shown on the item page under useful info. Note that the ad should be Responsive.', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                    </td>
                    <td><textarea name="ads_ip_un_info" rows="8"><?php echo osc_esc_html(osc_get_preference('ads_ip_un_info', 'marketplace_theme')); ?></textarea></td>
                </tr>
                
                <tr>
                    <td>
                        <?php _e('Item sidebar', 'marketplace') ?>:
                        <i id="tips" data-tipso='<?php _e('This ad will be shown on the item page sidebar. Note that the ad should be Responsive.', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                    </td>
                    <td><textarea name="ads_ip_sidebar" rows="8"><?php echo osc_esc_html(osc_get_preference('ads_ip_sidebar', 'marketplace_theme')); ?></textarea></td>
                </tr>
            </table> 
            
            <div class="form-actions">
                <input type="submit" id="save_changes" value="<?php echo osc_esc_html(__("Save changes", 'marketplace')); ?>" class="btn btn-submit">
            </div>        
        </form>
    </div>
</div>