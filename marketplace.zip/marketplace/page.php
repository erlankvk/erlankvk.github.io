<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        <div class="c_page">
            <div class="c_reg-top">
        		<div class="c_reg-head"><?php echo osc_static_page_title(); ?></div>
        	</div>
            <div class="c_pagetext">
            <?php echo osc_static_page_text(); ?>
			</div>
        </div>
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>